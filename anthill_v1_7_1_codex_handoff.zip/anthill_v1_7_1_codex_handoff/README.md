# ANTHILL Core v1.7.1

Scheduler hardening checkpoint built on the v1.7.0 task graph release and the v1.6.4 security-reviewed baseline.

## What Changed In v1.7.1

- **Public validation parity**: `validate_task_dependency_contract()` now detects duplicate task IDs like `TaskScheduler.validate_graph()` so self-test/public validation cannot silently lag runtime scheduling.
- **Duplicate task ID safety**: Duplicate IDs produce `duplicate_task_id`; ambiguous duplicate tasks are skipped and excluded from scheduler lookup state instead of overwriting each other.
- **Graph result permission**: `/graph?include_results=true` and mission graph result export now require `read_graph_results`. Default graph export remains metadata-first and excludes full result summaries.
- **Cancellation placeholder clarified**: `cancelled` remains a persisted lifecycle placeholder, but v1.7.1 does not expose a fake runtime cancellation pathway.
- **Parallel scheduler regression tests**: Added ready-queue coverage proving running tasks are excluded while independent ready tasks can continue.
- **v1.7.0 foundation preserved**: `anthill/core/scheduler.py` still owns dependency validation, ready/blocked transitions, skipped downstream tasks, bounded retries, lifecycle metadata, and graph export. `Queen.run_mission` remains the orchestrator.

## Security Baseline Preserved

- **Token enforcement**: API refuses to start if `ANTHILL_API_TOKEN` is still the default placeholder or fewer than 32 characters.
- **Rate limiting**: `/missions` is capped at 10 calls/minute per IP. Failed auth attempts are capped at 20/minute per IP; successful authenticated API calls do not consume the failure bucket.
- **Security headers**: Every API response carries `X-Frame-Options`, `X-Content-Type-Options`, `Content-Security-Policy`, and `Referrer-Policy`.
- **Docs disabled**: FastAPI `/docs`, `/redoc`, and `/openapi.json` are off by default. Use `/status` or `/schema` instead.
- **SSRF/local URL filtering**: Web search results pointing to private, loopback, local, malformed, or non-http(s) targets are silently dropped before being returned to agents.
- **Prompt injection prefix**: Agent system prompts open with a system-boundary instruction that tells the model to treat user-supplied goal text as data only.
- **DB permissions**: SQLite files and backups are best-effort hardened to owner read/write only.
- **Automatic DB backup**: A timestamped DB snapshot is taken at mission start for both CLI and API runs, stored in `backup_dir`.
- **Tool gates**: Shell, file writing, patch application, and web search remain disabled by default unless intentionally enabled.

## Install Dependencies

```powershell
pip install pydantic rich requests fastapi uvicorn pytest
```

Optional local model:

```powershell
ollama pull llama3.1:8b
```

## Validate

```powershell
Get-ChildItem -Recurse -Filter *.py | ForEach-Object { python -m py_compile $_.FullName }
python -m pytest -q
python -m anthill --selftest
```

Expected v1.7.1 baseline:

```text
pytest: 20 passed
selftest: 15 checks passed, 0 failed, 0 warnings
```

## Run API/UI

```powershell
# Token MUST be set: minimum 32 characters, not the default placeholder.
$env:ANTHILL_API_TOKEN="your-strong-random-token-here-min32chars"
python -m anthill --api
```

Open:

```text
http://127.0.0.1:8713/ui
```

## Security Notes

- Keep `.anthill/` out of version control and out of synced folders. It contains mission history and the SQLite DB.
- Run `pip-audit` or `safety check` before deploying to catch CVEs in dependencies.
- The `/docs` Swagger UI is disabled. Re-enable only for local development by explicitly changing the FastAPI config.
- The API is local-only (`127.0.0.1`) by default. Do not expose port 8713 externally without TLS and a reverse proxy.

## Codex Handoff

This repo includes a Codex handoff package for continuing beyond v1.7.1:

- `AGENTS.md` - standing instructions for coding agents.
- `docs/CODEX_START_HERE.md` - immediate handoff and commands.
- `docs/VERSION_STATE.md` - current checkpoint and validation baseline.
- `docs/SECURITY_RULES.md` - security invariants that must not be weakened.
- `docs/V1_7_BUILD_SPEC.md` - completed scheduler/task graph target for v1.7.0.
- `docs/V1_7_NOTES.md` - v1.7.0/v1.7.1 scheduler notes and remaining boundaries.
- `docs/CODEX_PROMPTS.md` - copy/paste prompts for Codex.
- `docs/NORTH_STAR.md` - full ANTHILL end-state, anti-drift rules, architectural pillars, staged future, and durable data contracts.
- `docs/STAGE_BLUEPRINT.md` - implementation-facing version/stage boundaries.

The next likely build is v1.7.2 mission recovery, scheduler diagnostics, and structured event/ledger work. Do not jump to v1.8/RAG/UI yet.
