# Codex Notes

Codex should treat `AGENTS.md` as the root instruction file and should read `docs/CODEX_START_HERE.md` before implementation work.

Do not store secrets or runtime state in this folder.
