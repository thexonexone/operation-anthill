from anthill import ANTHILL_VERSION, Queen, SQLiteMemory
from anthill.core.scheduler import SchedulerNotImplemented


def test_imports():
    assert ANTHILL_VERSION == "1.7.1"
    assert Queen is not None
    assert SQLiteMemory is not None
    assert SchedulerNotImplemented is not None
