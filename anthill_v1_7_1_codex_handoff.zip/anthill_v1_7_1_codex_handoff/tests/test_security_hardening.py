import pytest

from anthill.runtime import (
    API_TOKEN_MIN_LENGTH,
    API_TOKEN_DEFAULT_PLACEHOLDER,
    validate_api_token_strength,
    is_blocked_outbound_url,
    _RateLimiter,
)


def test_api_token_validation_rejects_default_and_short_tokens():
    with pytest.raises(RuntimeError):
        validate_api_token_strength(API_TOKEN_DEFAULT_PLACEHOLDER)
    with pytest.raises(RuntimeError):
        validate_api_token_strength("short-token")
    validate_api_token_strength("x" * API_TOKEN_MIN_LENGTH)


def test_outbound_url_filter_blocks_local_private_and_non_http_targets():
    assert is_blocked_outbound_url("http://127.0.0.1:8713/status")
    assert is_blocked_outbound_url("http://192.168.1.50/status")
    assert is_blocked_outbound_url("file:///etc/passwd")
    assert is_blocked_outbound_url("http://localhost:8713/status")
    assert not is_blocked_outbound_url("https://example.com/docs")


def test_rate_limiter_can_check_failures_without_counting_successful_checks():
    limiter = _RateLimiter(window_seconds=60, max_calls=2)
    assert not limiter.is_limited("client")
    assert not limiter.is_limited("client")
    limiter.record_attempt("client")
    assert not limiter.is_limited("client")
    limiter.record_attempt("client")
    assert limiter.is_limited("client")
    limiter.clear("client")
    assert not limiter.is_limited("client")
