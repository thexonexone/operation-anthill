from pathlib import Path

import pytest

from anthill.core.scheduler import TaskScheduler
from anthill.runtime import (
    Mission,
    MissionStatus,
    Queen,
    SQLiteMemory,
    Task,
    TaskStatus,
    validate_task_dependency_contract,
)
import anthill.runtime as runtime


def make_task(title, depends_on=None, max_attempts=1):
    return Task(
        title=title,
        description=title,
        assigned_ant="builder",
        task_type="build_answer",
        depends_on=depends_on or [],
        max_attempts=max_attempts,
    )


def test_linear_dependency_order():
    first = make_task("first")
    second = make_task("second", depends_on=[first.id])
    scheduler = TaskScheduler([first, second], mission_id="mission-1")

    assert scheduler.prepare() == []
    assert first.status == TaskStatus.READY
    assert second.status == TaskStatus.BLOCKED

    assert scheduler.next_ready_task().id == first.id
    scheduler.mark_running(first.id)
    scheduler.mark_complete(first.id, result="done")

    assert second.status == TaskStatus.READY


def test_branching_dependency_graph_fan_out_and_fan_in():
    root = make_task("root")
    branch_a = make_task("branch a", depends_on=[root.id])
    branch_b = make_task("branch b", depends_on=[root.id])
    join = make_task("join", depends_on=[branch_a.id, branch_b.id])
    scheduler = TaskScheduler([root, branch_a, branch_b, join], mission_id="mission-1")

    scheduler.prepare()
    assert [task.id for task in scheduler.ready_tasks()] == [root.id]

    scheduler.mark_running(root.id)
    scheduler.mark_complete(root.id, result="root done")
    assert {task.id for task in scheduler.ready_tasks()} == {branch_a.id, branch_b.id}
    assert join.status == TaskStatus.BLOCKED

    scheduler.mark_running(branch_a.id)
    scheduler.mark_complete(branch_a.id, result="a done")
    assert join.status == TaskStatus.BLOCKED

    scheduler.mark_running(branch_b.id)
    scheduler.mark_complete(branch_b.id, result="b done")
    assert join.status == TaskStatus.READY


def test_blocked_task_becomes_ready_after_dependency_completes():
    dependency = make_task("dependency")
    blocked = make_task("blocked", depends_on=[dependency.id])
    scheduler = TaskScheduler([dependency, blocked], mission_id="mission-1")

    scheduler.prepare()
    assert blocked.status == TaskStatus.BLOCKED
    assert blocked.blocked_reason

    scheduler.mark_running(dependency.id)
    scheduler.mark_complete(dependency.id, result="complete")

    assert blocked.status == TaskStatus.READY
    assert blocked.blocked_reason is None


def test_permanently_failed_dependency_causes_downstream_skipped():
    dependency = make_task("dependency")
    downstream = make_task("downstream", depends_on=[dependency.id])
    scheduler = TaskScheduler([dependency, downstream], mission_id="mission-1")

    scheduler.prepare()
    scheduler.mark_running(dependency.id)
    terminal = scheduler.mark_failed(dependency.id, "boom", failure_type="execution_error", retryable=False)

    assert terminal is True
    assert dependency.status == TaskStatus.FAILED
    assert downstream.status == TaskStatus.SKIPPED
    assert downstream.skipped_reason


def test_task_retry_increments_attempt_count_then_succeeds():
    task = make_task("retry me", max_attempts=2)
    scheduler = TaskScheduler([task], mission_id="mission-1")

    scheduler.prepare()
    scheduler.mark_running(task.id)
    terminal = scheduler.mark_failed(task.id, "temporary", failure_type="execution_error", retryable=True)

    assert terminal is False
    assert task.attempt_count == 1
    assert task.status == TaskStatus.READY

    scheduler.mark_running(task.id)
    scheduler.mark_complete(task.id, result="ok")

    assert task.attempt_count == 2
    assert task.status == TaskStatus.COMPLETE


def test_task_exhausts_max_attempts_and_becomes_failed():
    task = make_task("retry me", max_attempts=2)
    scheduler = TaskScheduler([task], mission_id="mission-1")

    scheduler.prepare()
    scheduler.mark_running(task.id)
    assert scheduler.mark_failed(task.id, "temporary", retryable=True) is False
    scheduler.mark_running(task.id)
    assert scheduler.mark_failed(task.id, "terminal", retryable=True) is True

    assert task.attempt_count == 2
    assert task.status == TaskStatus.FAILED
    assert task.failed_at is not None


def test_graph_validation_detects_missing_dependency_and_cycle():
    missing = make_task("missing", depends_on=["does-not-exist"])
    cycle_a = make_task("cycle a")
    cycle_b = make_task("cycle b", depends_on=[cycle_a.id])
    cycle_a.depends_on = [cycle_b.id]
    scheduler = TaskScheduler([missing, cycle_a, cycle_b], mission_id="mission-1")

    issue_codes = {issue.code for issue in scheduler.validate_graph()}

    assert "missing_dependency" in issue_codes
    assert "cycle" in issue_codes


def test_duplicate_task_ids_are_reported_and_not_silently_overwritten():
    first = make_task("first duplicate")
    second = make_task("second duplicate")
    second.id = first.id
    dependent = make_task("dependent", depends_on=[first.id])
    scheduler = TaskScheduler([first, second, dependent], mission_id="mission-1")

    issues = scheduler.prepare()
    issue_codes = {issue.code for issue in issues}

    assert "duplicate_task_id" in issue_codes
    assert first.id not in scheduler.task_by_id
    assert first.status == TaskStatus.SKIPPED
    assert second.status == TaskStatus.SKIPPED
    assert dependent.status == TaskStatus.SKIPPED
    assert scheduler.ready_tasks() == []
    assert scheduler.mark_running(first.id) is False


def test_public_dependency_contract_detects_duplicate_task_ids():
    first = make_task("first duplicate")
    second = make_task("second duplicate")
    second.id = first.id
    dependent = make_task("dependent", depends_on=[first.id])

    errors = validate_task_dependency_contract([first, second, dependent])

    assert any("Duplicate task id" in error for error in errors)
    assert any("depends on missing task id" in error for error in errors)


def test_parallel_ready_queue_excludes_running_tasks():
    first = make_task("parallel one")
    second = make_task("parallel two")
    join = make_task("join", depends_on=[first.id, second.id])
    scheduler = TaskScheduler([first, second, join], mission_id="mission-1")

    scheduler.prepare()
    assert {task.id for task in scheduler.ready_tasks()} == {first.id, second.id}

    assert scheduler.mark_running(first.id) is True
    assert [task.id for task in scheduler.ready_tasks()] == [second.id]
    assert join.status == TaskStatus.BLOCKED

    scheduler.mark_complete(first.id, result="first done")
    assert [task.id for task in scheduler.ready_tasks()] == [second.id]

    scheduler.mark_running(second.id)
    scheduler.mark_complete(second.id, result="second done")
    assert [task.id for task in scheduler.ready_tasks()] == [join.id]


def test_cancelled_status_is_placeholder_not_runtime_pathway():
    task = make_task("placeholder cancel")
    scheduler = TaskScheduler([task], mission_id="mission-1")

    scheduler.prepare()
    scheduler.skip_remaining("mission stopped")

    assert task.status == TaskStatus.SKIPPED
    assert task.status != TaskStatus.CANCELLED
    assert not hasattr(scheduler, "mark_cancelled")


def test_graph_export_excludes_full_result_summary_by_default():
    task = make_task("summarized")
    task.result_summary = "token=super-secret-value build completed"
    scheduler = TaskScheduler([task], mission_id="mission-1")

    graph = scheduler.export_graph()
    node = graph["nodes"][0]

    assert "result_summary" not in node
    assert "result_summary_preview" in node
    assert "super-secret-value" not in node["result_summary_preview"]


def test_runtime_graph_export_is_safe_by_default_while_local_views_keep_summaries(tmp_path):
    memory = SQLiteMemory(str(tmp_path / "graph-safe.db"))
    queen = Queen()
    queen.memory = memory
    task = Task(
        title="local summary task",
        description="local summary task",
        assigned_ant="builder",
        task_type="build_answer",
        status=TaskStatus.COMPLETE,
        result="full local task output",
        result_summary="safe local summary preview",
    )
    mission = Mission(
        goal="local-token graph safety check",
        tasks=[task],
        status=MissionStatus.COMPLETE,
        user_result="local mission result",
        final_result="local mission result",
    )
    memory.save_mission(mission)
    queen.last_mission_id = mission.id

    graph = queen.build_task_graph_data(mission_id=mission.id)
    node = graph["nodes"][0]
    task_rows = memory.get_tasks_for_mission(mission.id)
    mission_detail = queen.format_mission_detail(mission.id)

    assert "result_summary" not in node
    assert node["result_summary_preview"] == "safe local summary preview"
    # /tasks and mission detail are local-token dev-mode views and still expose
    # task summaries. Do not widen /graph to match them.
    assert task_rows[0]["result_summary"] == "safe local summary preview"
    assert "safe local summary preview" in mission_detail


def test_graph_result_export_requires_stronger_permission(monkeypatch):
    monkeypatch.setitem(runtime.API_PERMISSIONS, "read_graph", True)
    monkeypatch.setitem(runtime.API_PERMISSIONS, "read_graph_results", False)

    class DummyMemory:
        def __init__(self):
            self.events = []

        def get_mission(self, mission_id):
            return {"id": mission_id, "status": "complete"}

        def log_event(self, **kwargs):
            self.events.append(kwargs)

    class DummyQueen:
        def __init__(self):
            self.memory = DummyMemory()
            self.last_mission_id = None

    queen = DummyQueen()

    assert runtime.api_permission_allowed("read_graph")
    assert not runtime.api_permission_allowed("read_graph_results")
    with pytest.raises(runtime.HTTPException) as error:
        runtime.require_api_permission(queen, "read_graph_results", "read task graph result summaries")

    assert error.value.status_code == 403
    assert queen.memory.events[-1]["metadata"]["permission"] == "read_graph_results"


def test_sqlite_memory_tracks_scheduler_lifecycle_columns(tmp_path):
    memory = SQLiteMemory(str(tmp_path / "migration.db"))
    status = memory.get_schema_status()

    with memory._connect() as conn:
        cursor = conn.cursor()
        cursor.execute("PRAGMA table_info(tasks)")
        task_columns = {row[1] for row in cursor.fetchall()}

    assert status["schema_version"] == runtime.ANTHILL_SCHEMA_VERSION
    assert status["migration_count"] >= runtime.ANTHILL_SCHEMA_VERSION
    assert {
        "attempt_count",
        "max_attempts",
        "failure_reason",
        "failure_type",
        "failed_at",
        "skipped_reason",
        "skipped_at",
        "blocked_reason",
        "parent_task_id",
    }.issubset(task_columns)


def test_queen_run_mission_completes_basic_scheduler_mission(tmp_path, monkeypatch):
    db_path = tmp_path / "anthill.db"
    monkeypatch.setattr(runtime, "ANTHILL_DB_PATH", str(db_path))
    monkeypatch.setattr(runtime, "BACKUP_DIR", str(tmp_path / "backups"))
    monkeypatch.setattr(runtime, "ENABLE_PARALLEL_EXECUTION", False)

    class DummyAnt:
        def run(self, task, mission):
            return f"completed {task.title}"

    queen = Queen()
    queen.memory = SQLiteMemory(str(db_path))
    first = Task(title="first", description="first", assigned_ant="dummy", task_type="build_answer")
    second = Task(title="second", description="second", assigned_ant="dummy", task_type="build_answer", depends_on=[first.id])
    queen.planner.create_tasks = lambda *args, **kwargs: [first, second]
    queen.ants = {"dummy": DummyAnt()}

    result = queen.run_mission("basic scheduler mission")
    rows = queen.memory.get_tasks_for_mission(queen.last_mission_id)

    assert "Mission Complete" in result
    assert queen.last_mission_id
    assert [row["status"] for row in rows] == [TaskStatus.COMPLETE.value, TaskStatus.COMPLETE.value]
    assert [row["attempt_count"] for row in rows] == [1, 1]
    assert Path(db_path).exists()
