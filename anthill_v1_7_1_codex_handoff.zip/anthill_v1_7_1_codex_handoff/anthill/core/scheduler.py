"""Dependency-aware task scheduler for ANTHILL v1.7.x."""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import Any, Callable, Dict, Iterable, List, Optional, Set

from ..runtime import Task, TaskStatus, now_utc, truncate_text


class SchedulerNotImplemented(RuntimeError):
    """Compatibility symbol retained for v1.6.x import checks."""


@dataclass(frozen=True)
class TaskGraphIssue:
    code: str
    task_id: str
    message: str
    dependency_id: Optional[str] = None


@dataclass(frozen=True)
class TaskTransition:
    task_id: str
    from_status: str
    to_status: str
    reason: Optional[str] = None
    reason_type: Optional[str] = None


TERMINAL_STATUSES = {
    TaskStatus.COMPLETE,
    TaskStatus.FAILED,
    TaskStatus.SKIPPED,
    TaskStatus.CANCELLED,
}

NON_TERMINAL_STATUSES = {
    TaskStatus.PENDING,
    TaskStatus.READY,
    TaskStatus.BLOCKED,
    TaskStatus.RUNNING,
}

PERMANENTLY_UNMET_DEPENDENCY_STATUSES = {
    TaskStatus.FAILED,
    TaskStatus.SKIPPED,
    TaskStatus.CANCELLED,
}

WAITING_DEPENDENCY_STATUSES = {
    TaskStatus.PENDING,
    TaskStatus.READY,
    TaskStatus.BLOCKED,
    TaskStatus.RUNNING,
}

_SENSITIVE_ASSIGNMENT_RE = re.compile(
    r"(?i)\b(token|api[_-]?key|password|passwd|secret|authorization)\b\s*[:=]\s*[^,\s;]+",
)


def _status_value(status: Any) -> str:
    return getattr(status, "value", str(status))


class TaskScheduler:
    """Pure task graph state machine.

    The scheduler mutates the supplied Task objects, but it does not know how to
    execute ants, save memory, or print output. Queen remains the orchestrator.
    """

    def __init__(
        self,
        tasks: Iterable[Task],
        mission_id: Optional[str] = None,
        now_fn: Callable[[], Any] = now_utc,
    ) -> None:
        self.tasks: List[Task] = list(tasks)
        id_counts: Dict[str, int] = {}
        for task in self.tasks:
            id_counts[task.id] = id_counts.get(task.id, 0) + 1
        self.duplicate_task_ids: Set[str] = {
            task_id for task_id, count in id_counts.items() if count > 1
        }
        # Do not expose duplicate IDs through task_by_id. A dict comprehension
        # would silently overwrite earlier tasks and make execution ambiguous.
        self.task_by_id: Dict[str, Task] = {
            task.id: task for task in self.tasks if task.id not in self.duplicate_task_ids
        }
        self.mission_id = mission_id
        self.now_fn = now_fn
        self.validation_issues: List[TaskGraphIssue] = []
        self._transitions: List[TaskTransition] = []

    def validate_graph(self) -> List[TaskGraphIssue]:
        issues: List[TaskGraphIssue] = []
        task_ids = set(self.task_by_id)
        for duplicate_id in sorted(self.duplicate_task_ids):
            issues.append(
                TaskGraphIssue(
                    code="duplicate_task_id",
                    task_id=duplicate_id,
                    message=f"Duplicate task id {duplicate_id} appears more than once.",
                )
            )
        for task in self.tasks:
            for dep_id in self.dependency_ids(task):
                if dep_id == task.id:
                    issues.append(
                        TaskGraphIssue(
                            code="self_dependency",
                            task_id=task.id,
                            dependency_id=dep_id,
                            message=f"Task {task.id} depends on itself.",
                        )
                    )
                elif dep_id not in task_ids:
                    issues.append(
                        TaskGraphIssue(
                            code="missing_dependency",
                            task_id=task.id,
                            dependency_id=dep_id,
                            message=f"Task {task.id} depends on missing task id {dep_id}.",
                        )
                    )
            for parent_id in self.parent_ids(task):
                if parent_id == task.id:
                    issues.append(
                        TaskGraphIssue(
                            code="self_parent",
                            task_id=task.id,
                            dependency_id=parent_id,
                            message=f"Task {task.id} lists itself as a parent.",
                        )
                    )

        for task_id in sorted(self._cycle_task_ids()):
            issues.append(
                TaskGraphIssue(
                    code="cycle",
                    task_id=task_id,
                    message=f"Task {task_id} participates in a dependency cycle.",
                )
            )
        self.validation_issues = issues
        return issues

    def prepare(self) -> List[TaskGraphIssue]:
        """Validate the graph and move invalid tasks to skipped."""

        issues = self.validate_graph()
        for issue in issues:
            if issue.code == "duplicate_task_id":
                for task in self._tasks_for_id(issue.task_id):
                    if task.status not in TERMINAL_STATUSES:
                        self._set_status(task, TaskStatus.SKIPPED, issue.message, issue.code)
            elif issue.code in {"self_dependency", "missing_dependency", "cycle"}:
                task = self.task_by_id.get(issue.task_id)
                if task and task.status not in TERMINAL_STATUSES:
                    self.mark_skipped(task.id, issue.message, reason_type=issue.code)
        self.evaluate()
        return issues

    def evaluate(self) -> None:
        """Refresh pending/blocked/ready/skipped states from dependency state."""

        changed = True
        while changed:
            changed = False
            for task in self.tasks:
                if task.status in TERMINAL_STATUSES or task.status == TaskStatus.RUNNING:
                    continue
                if task.id in self.duplicate_task_ids:
                    reason = f"Task skipped because duplicate task id is ambiguous: {task.id}"
                    changed = self._set_status(task, TaskStatus.SKIPPED, reason, "duplicate_task_id") or changed
                    continue

                dep_ids = self.dependency_ids(task)
                if not dep_ids:
                    changed = self._set_status(task, TaskStatus.READY, None, None) or changed
                    continue

                missing = [dep_id for dep_id in dep_ids if dep_id not in self.task_by_id]
                if missing:
                    reason = f"Task skipped because dependencies are missing: {missing}"
                    changed = self._set_status(task, TaskStatus.SKIPPED, reason, "missing_dependency") or changed
                    continue

                dependency_statuses = {
                    dep_id: self.task_by_id[dep_id].status for dep_id in dep_ids
                }
                terminally_unmet = [
                    dep_id
                    for dep_id, status in dependency_statuses.items()
                    if status in PERMANENTLY_UNMET_DEPENDENCY_STATUSES
                ]
                if terminally_unmet:
                    reason = (
                        "Task skipped because dependencies cannot complete: "
                        f"{terminally_unmet}"
                    )
                    changed = self._set_status(task, TaskStatus.SKIPPED, reason, "failed_dependency") or changed
                    continue

                waiting = [
                    dep_id
                    for dep_id, status in dependency_statuses.items()
                    if status in WAITING_DEPENDENCY_STATUSES
                ]
                if waiting:
                    reason = f"Waiting on dependencies: {waiting}"
                    changed = self._set_status(task, TaskStatus.BLOCKED, reason, "waiting_dependency") or changed
                    continue

                changed = self._set_status(task, TaskStatus.READY, None, None) or changed

    def ready_tasks(self) -> List[Task]:
        self.evaluate()
        return [task for task in self.tasks if task.status == TaskStatus.READY]

    def next_ready_task(self) -> Optional[Task]:
        ready = self.ready_tasks()
        return ready[0] if ready else None

    def mark_running(self, task_id: str) -> bool:
        if task_id in self.duplicate_task_ids:
            return False
        task = self.task_by_id[task_id]
        if task.status not in {TaskStatus.READY, TaskStatus.PENDING}:
            return False
        task.attempt_count = int(task.attempt_count or 0) + 1
        task.started_at = self.now_fn()
        task.finished_at = None
        task.elapsed_seconds = None
        task.blocked_reason = None
        return self._set_status(task, TaskStatus.RUNNING, None, None)

    def mark_complete(
        self,
        task_id: str,
        result: Optional[str] = None,
        completed_at: Optional[Any] = None,
        elapsed_seconds: Optional[float] = None,
    ) -> None:
        task = self.task_by_id[task_id]
        if result is not None:
            task.result = result
        completed = completed_at or self.now_fn()
        task.completed_at = completed
        task.finished_at = completed
        task.elapsed_seconds = elapsed_seconds
        task.failure_reason = None
        task.failure_type = None
        task.blocked_reason = None
        self._set_status(task, TaskStatus.COMPLETE, None, None)
        self.evaluate()

    def mark_failed(
        self,
        task_id: str,
        reason: str,
        failure_type: str = "execution_error",
        retryable: bool = True,
        failed_at: Optional[Any] = None,
        elapsed_seconds: Optional[float] = None,
    ) -> bool:
        """Mark a task attempt failed.

        Returns True when the task is terminally failed. Returns False when a
        bounded retry was scheduled and the task is ready to run again.
        """

        task = self.task_by_id[task_id]
        task.failure_reason = reason
        task.failure_type = failure_type
        task.result = reason
        task.finished_at = failed_at or self.now_fn()
        task.elapsed_seconds = elapsed_seconds
        max_attempts = max(1, int(task.max_attempts or 1))
        attempts = max(0, int(task.attempt_count or 0))
        if retryable and attempts < max_attempts:
            self._set_status(
                task,
                TaskStatus.READY,
                f"Retry scheduled after failed attempt {attempts}/{max_attempts}: {reason}",
                "retry_scheduled",
            )
            return False
        task.failed_at = failed_at or self.now_fn()
        self._set_status(task, TaskStatus.FAILED, reason, failure_type)
        self.evaluate()
        return True

    def mark_skipped(
        self,
        task_id: str,
        reason: str,
        reason_type: str = "skipped",
    ) -> None:
        if task_id in self.duplicate_task_ids:
            for task in self._tasks_for_id(task_id):
                self._set_status(task, TaskStatus.SKIPPED, reason, reason_type)
            self.evaluate()
            return
        task = self.task_by_id[task_id]
        self._set_status(task, TaskStatus.SKIPPED, reason, reason_type)
        self.evaluate()

    def skip_remaining(self, reason: str, reason_type: str = "scheduler_stop") -> None:
        for task in self.tasks:
            if task.status in {TaskStatus.PENDING, TaskStatus.READY, TaskStatus.BLOCKED}:
                self.mark_skipped(task.id, reason, reason_type=reason_type)

    def is_finished(self) -> bool:
        return all(task.status in TERMINAL_STATUSES for task in self.tasks)

    def consume_transitions(self) -> List[TaskTransition]:
        transitions = list(self._transitions)
        self._transitions.clear()
        return transitions

    def export_graph(
        self,
        include_results: bool = False,
        include_result_preview: bool = True,
        preview_chars: int = 240,
    ) -> Dict[str, Any]:
        self.evaluate()
        child_ids: Dict[str, List[str]] = {task.id: [] for task in self.tasks}
        edges: List[Dict[str, str]] = []
        for task in self.tasks:
            for dep_id in self.dependency_ids(task):
                edges.append({"from": dep_id, "to": task.id, "type": "depends_on"})
                if dep_id in child_ids:
                    child_ids[dep_id].append(task.id)
            for parent_id in self.parent_ids(task):
                edges.append({"from": parent_id, "to": task.id, "type": "parent_task"})
                if parent_id in child_ids:
                    child_ids[parent_id].append(task.id)

        nodes: List[Dict[str, Any]] = []
        for task in self.tasks:
            node = {
                "mission_id": self.mission_id,
                "task_id": task.id,
                "title": task.title,
                "name": task.title,
                "assigned_ant": task.assigned_ant,
                "assigned_agent": task.assigned_ant,
                "role": task.assigned_ant,
                "task_type": task.task_type,
                "status": _status_value(task.status),
                "dependency_ids": self.dependency_ids(task),
                "depends_on": self.dependency_ids(task),
                "parent_task_id": task.parent_task_id,
                "parent_task_ids": self.parent_ids(task),
                "child_task_ids": sorted(set(child_ids.get(task.id, []))),
                "attempt_count": task.attempt_count,
                "max_attempts": task.max_attempts,
                "created_at": task.created_at.isoformat() if task.created_at else None,
                "started_at": task.started_at.isoformat() if task.started_at else None,
                "completed_at": task.completed_at.isoformat() if task.completed_at else None,
                "failed_at": task.failed_at.isoformat() if task.failed_at else None,
                "skipped_at": task.skipped_at.isoformat() if task.skipped_at else None,
                "failure_type": task.failure_type,
                "status_message": self.status_message(task),
                "elapsed_seconds": task.elapsed_seconds,
            }
            if include_result_preview and task.result_summary:
                node["result_summary_preview"] = self._safe_preview(task.result_summary, preview_chars)
            if include_results:
                node["result_summary"] = task.result_summary
            nodes.append(node)

        return {
            "schema_version": "task-graph-v2",
            "mission_id": self.mission_id,
            "nodes": nodes,
            "edges": edges,
            "validation_issues": [issue.__dict__ for issue in self.validation_issues],
        }

    def status_message(self, task: Task) -> Optional[str]:
        if task.status == TaskStatus.FAILED:
            return task.failure_reason
        if task.status == TaskStatus.SKIPPED:
            return task.skipped_reason
        if task.status == TaskStatus.BLOCKED:
            return task.blocked_reason
        if task.status == TaskStatus.READY:
            return "Dependencies satisfied; task is ready to run."
        return None

    def dependency_ids(self, task: Task) -> List[str]:
        return [str(dep_id) for dep_id in (task.depends_on or []) if str(dep_id)]

    def parent_ids(self, task: Task) -> List[str]:
        ids = [str(parent_id) for parent_id in (task.parent_task_ids or []) if str(parent_id)]
        if task.parent_task_id and task.parent_task_id not in ids:
            ids.append(task.parent_task_id)
        return ids

    def _tasks_for_id(self, task_id: str) -> List[Task]:
        return [task for task in self.tasks if task.id == task_id]

    def _set_status(
        self,
        task: Task,
        status: TaskStatus,
        reason: Optional[str],
        reason_type: Optional[str],
    ) -> bool:
        previous = task.status
        if previous == status:
            if status == TaskStatus.BLOCKED and reason:
                task.blocked_reason = reason
            return False

        now = self.now_fn()
        task.status = status
        if status == TaskStatus.READY:
            task.blocked_reason = None
        elif status == TaskStatus.BLOCKED:
            task.blocked_reason = reason
        elif status == TaskStatus.SKIPPED:
            task.skipped_reason = reason
            task.skipped_at = now
            task.finished_at = now
            if task.elapsed_seconds is None:
                task.elapsed_seconds = 0.0
        elif status == TaskStatus.FAILED:
            task.failure_reason = reason
            task.failure_type = reason_type
            task.failed_at = now
            task.finished_at = now
        elif status == TaskStatus.CANCELLED:
            task.skipped_reason = reason
            task.skipped_at = now
            task.finished_at = now
            if task.elapsed_seconds is None:
                task.elapsed_seconds = 0.0
        self._transitions.append(
            TaskTransition(
                task_id=task.id,
                from_status=_status_value(previous),
                to_status=_status_value(status),
                reason=reason,
                reason_type=reason_type,
            )
        )
        return True

    def _cycle_task_ids(self) -> Set[str]:
        visiting: Set[str] = set()
        visited: Set[str] = set()
        in_cycle: Set[str] = set()

        def visit(task_id: str, path: List[str]) -> None:
            if task_id in visiting:
                try:
                    start = path.index(task_id)
                    in_cycle.update(path[start:])
                except ValueError:
                    in_cycle.add(task_id)
                return
            if task_id in visited:
                return
            visiting.add(task_id)
            task = self.task_by_id.get(task_id)
            if task:
                for dep_id in self.dependency_ids(task):
                    if dep_id in self.task_by_id:
                        visit(dep_id, path + [dep_id])
            visiting.remove(task_id)
            visited.add(task_id)

        for task in self.tasks:
            visit(task.id, [task.id])
        return in_cycle

    def _safe_preview(self, value: str, max_chars: int) -> str:
        redacted = _SENSITIVE_ASSIGNMENT_RE.sub(r"\1=[redacted]", value or "")
        return truncate_text(redacted, max_chars, suffix="...[preview truncated]")


__all__ = [
    "SchedulerNotImplemented",
    "TaskGraphIssue",
    "TaskScheduler",
    "TaskTransition",
    "TERMINAL_STATUSES",
]
