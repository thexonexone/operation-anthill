# ANTHILL Security Rules

These rules exist so Codex or any future coding agent does not accidentally weaken ANTHILL while adding features.

## Default posture

ANTHILL is local-first and must fail closed.

Default behavior should remain:

- API host: `127.0.0.1`.
- API auth: enabled.
- Web search: disabled.
- Shell tool: disabled.
- File writing: disabled.
- Patch application: disabled.
- Runtime workspace: `.anthill/`, not committed.

## Secrets and repo hygiene

Never commit:

- `.env`.
- API keys or real tokens.
- `.anthill/` runtime folders.
- SQLite DB files.
- DB WAL/SHM files.
- Logs, exports, backups, caches, virtualenvs, generated zips.

Use `.env.example` only for placeholders.

## API security invariants

Do not weaken:

- `ANTHILL_API_TOKEN` minimum length enforcement.
- Rejection of the default placeholder token.
- Constant-time token comparison.
- Failed-auth rate limiter.
- Mission submission rate limiter.
- API startup protection against unauthenticated non-loopback binding.
- Default-disabled `/docs`, `/redoc`, and `/openapi.json`.
- Security response headers.

If a future dev profile enables docs or non-loopback binding, it must be explicit, documented, and protected by auth/TLS/reverse proxy assumptions. Do not make it the default.

## Tool security invariants

All external capabilities must remain gated:

- Shell commands require `shell_tool_enabled` / `ENABLE_SHELL_TOOL`.
- File writes require `file_writing_enabled` / `ENABLE_FILE_WRITING`.
- Patch application requires `patch_application_enabled` / `ENABLE_PATCH_APPLICATION`.
- Web search requires `web_search_enabled` / `ENABLE_WEB_SEARCH`.

Do not let an ant bypass the tool registry or permission checks.

## SSRF and web safety

Any URL that agents can see, store, or later fetch must pass URL filtering.

Blocked target categories include:

- loopback hosts/IPs,
- private IPs,
- link-local IPs,
- multicast/reserved/unspecified IPs,
- `.local`, `.localhost`, `localhost`,
- malformed or non-http(s) URLs.

Do not replace `ipaddress`-based validation with brittle string-prefix checks.

## Database safety

- SQLite runtime DB and backups should be best-effort `chmod 600`.
- DB backup should happen at mission start through shared mission flow, not API-only logic.
- Migrations should be idempotent and logged.
- Do not break existing schema version tracking.

## Prompt injection safety

Agent prompts include a system-boundary prefix that treats user goal text as data only. Do not remove this. Future improvements should strengthen it and add tests when possible.

## Scheduler security considerations for v1.7

The v1.7 scheduler must not create a path around security gates.

Scheduler rules:

- Task type does not imply permission.
- Agent assignment does not imply tool permission.
- Retry logic must not retry blocked permission-denied tool calls forever.
- Failed/unsafe verification should block mission completion or require explicit approval.
- Task graph export must not leak secrets, full env vars, raw tokens, local absolute paths from unauthenticated endpoints, or full raw file contents.

## Test requirements for security-sensitive edits

When touching auth, API binding, URL filtering, file paths, shell, patching, database, or scheduler permissions, add or update tests.

Minimum command set before calling a checkpoint complete:

```bash
python -m py_compile $(find . -name '*.py' -print)
python -m pytest -q
python -m anthill --selftest
```
