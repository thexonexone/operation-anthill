# ANTHILL Context

## Mission Statement

ANTHILL is a visible swarm-intelligence framework for AI agents. A Queen agent turns user requests into missions, specialized ant agents complete the work, and digital pheromone memory helps the system learn which paths succeed or fail. The goal is to create an adaptive, observable, and scalable AI system for technical operations, automation, troubleshooting, cybersecurity, and workflow execution.

ANTHILL should become a local-first AI OS harness: not just one chatbot, not just a prompt chain, and not just a UI demo. It should be a durable runtime where missions can be planned, delegated, verified, remembered, audited, and eventually visualized.

## Core Conceptual Roles

### Queen

The Queen owns mission intake and orchestration. It receives user requests, creates mission plans, routes tasks through the scheduler, dispatches ants, records events/memory, and returns a final answer.

### Scheduler

The scheduler owns task graph state. It understands dependencies, ready/blocked states, retries, failure propagation, skipped downstream work, duplicate-ID safety, and safe graph export. v1.7 made the scheduler a real core subsystem; v1.7.1 hardened validation parity, graph-result permissioning, cancellation-placeholder behavior, and scheduler regressions.

### Ant Workers

Ants are specialized execution roles. Current/future roles include:

- Researcher Ant - finds or summarizes context.
- Web Research Ant - uses gated web search when enabled.
- File Ant - reads allowed project files.
- Coder Ant - proposes patches or code changes.
- Builder Ant - assembles final outputs.
- Verifier Ant - checks task outputs and mission results.
- Future Shell/Tool Ants - operate only through strict permission gates.

### Tool Layer

Tools are permissioned capabilities, not free-for-all agent access. File writing, patch application, shell commands, and web search must remain gated and auditable.

### Memory

Memory has multiple layers:

- Mission/event ledger.
- Agent communication ledger.
- Task result summaries.
- Source records and source quality.
- Pheromone memory for successful/failed paths.
- Future semantic/RAG memory for durable recall.

### Verifier

The verifier checks whether outputs are valid before the Queen treats a mission as complete. Verification should become stricter over time and should eventually block unsafe or low-confidence mission completion.

## Future UI Vision

The UI should visualize the working backend rather than fake activity.

Long-term visual direction:

- A central Queen/core node.
- A dense 3D anthill/root-system style graph.
- Tunnels representing mission paths and task dependencies.
- Ants moving through tunnels as workers execute tasks.
- Digital pheromone trails showing repeated successful paths, failed paths, confidence, and learned routes.
- Zoom levels from high-level mission overview down to individual agent messages, tool calls, files, and verifier decisions.

The UI should come after the backend has real scheduler, memory, and observability data to render.

## Current Priority

Do not build UI yet. Do not jump to RAG yet. Do not add distributed workers yet.

Current priority is:

```text
v1.7.1 scheduler hardening checkpoint
-> v1.7.2 mission recovery and structured event ledger
-> v1.8 memory/RAG foundation
-> v1.9 worker swarm runtime
-> v2.0 local OS harness
-> v2.1+ visual dashboard/UI
```
