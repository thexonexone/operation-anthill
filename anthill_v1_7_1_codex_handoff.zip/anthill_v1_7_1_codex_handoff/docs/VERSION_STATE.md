# ANTHILL Version State

## Current official checkpoint

**Version:** v1.7.1 scheduler hardening checkpoint

**Purpose:** Harden the Stage 1 scheduler foundation with duplicate-ID validation parity, stricter graph result permissioning, explicit cancellation-placeholder behavior, and focused scheduler regressions.

**Runtime package version:** `1.7.1` in `pyproject.toml` and `ANTHILL_VERSION`.

**Schema version:** `ANTHILL_SCHEMA_VERSION = 7`.

## What v1.7.1 is

v1.7.0 replaced the placeholder scheduler boundary with a standalone `TaskScheduler` in `anthill/core/scheduler.py` and wired `Queen.run_mission` through it.

v1.7.1 hardens that checkpoint without expanding into UI, RAG, distributed workers, or new automation capabilities.

The Queen still orchestrates mission setup, ant dispatch, logging, verification, memory, and final reports. The scheduler owns dependency resolution, graph validation, ready/blocked transitions, retry state, duplicate-ID safety, and skipped downstream tasks.

## Scheduler behavior included

- Real task lifecycle states: `pending`, `ready`, `blocked`, `running`, `complete`, `failed`, `skipped`, and `cancelled`.
- Structural dependency validation for missing dependencies, self-dependencies, self-parent links, cycles, and duplicate task IDs.
- Duplicate task ID validation with `duplicate_task_id`; duplicate IDs are skipped and are not exposed through `task_by_id` lookup.
- Public `validate_task_dependency_contract()` duplicate-ID checks now match the scheduler so self-test/public validation cannot silently lag runtime scheduling.
- Dependency-aware ready queue calculation.
- Temporary `blocked` state for tasks waiting on dependencies.
- Terminal `skipped` state for tasks that cannot run because an upstream dependency failed or was skipped.
- Bounded retry handling with `attempt_count` and `max_attempts`.
- Terminal task failure metadata with `failure_reason`, `failure_type`, and `failed_at`.
- Skip/block metadata with `skipped_reason`, `skipped_at`, and `blocked_reason`.
- Metadata-first task graph export using `task-graph-v2`.
- Default graph export excludes full `result_summary` and raw task output.
- Full result graph export requires `read_graph_results`; default `read_graph` access is metadata-first.
- `/tasks` and mission detail are still local-token development/diagnostic views and may expose result summaries; do not widen `/graph` defaults to match them.
- `cancelled` is a lifecycle placeholder in v1.7.1, not a complete cancellation pathway.

## Security invariants preserved

v1.7.1 preserves the v1.6.4 security-reviewed controls:

- API token strength validation at API startup.
- Constant-time token comparison with `secrets.compare_digest`.
- Failed-auth rate limiter counts failed authentication attempts, not successful requests.
- Mission submission rate limiting.
- API startup protection: auth disabled cannot bind to `0.0.0.0` or another non-loopback host.
- Security headers on API responses.
- FastAPI docs/OpenAPI endpoints disabled by default.
- SSRF/local/private URL filtering with `ipaddress`-based checks.
- URL filtering before web results are returned and before source records are saved.
- SQLite DB and backup permission hardening.
- Pre-mission DB backup runs from `Queen.run_mission`, covering both CLI and API mission paths.
- Tool gates for shell, file writing, patch application, and web search remain fail-closed by default.

## Known design state

- `anthill/runtime.py` still contains most stable runtime implementation.
- `anthill/core/scheduler.py` contains the scheduler logic.
- Legacy Queen dependency helper methods are deprecated compatibility code; do not reintroduce ad hoc scheduling outside `TaskScheduler`.
- `Task`, `TaskStatus`, `Mission`, and scheduler models still import from `runtime.py`; move them later as a v1.8/v1.9 cleanup, not as a v1.7 blocker.
- The next stage should continue mission recovery, stuck-task diagnostics, timeout policy, structured event/ledger records, and partial mission summaries.

## Baseline validation target

A clean v1.7.1 checkpoint should pass:

```bash
python -m py_compile $(find . -name '*.py' -print)
python -m pytest -q
python -m anthill --selftest
```

PowerShell equivalent:

```powershell
Get-ChildItem -Recurse -Filter *.py | ForEach-Object { python -m py_compile $_.FullName }
python -m pytest -q
python -m anthill --selftest
```

Validated baseline for this checkpoint:

```text
py_compile: passed
pytest: 20 passed
selftest: 15 checks passed, 0 failed, 0 warnings
```

## Next likely version

**v1.7.2 -- Mission recovery, scheduler diagnostics, and structured event ledger**

Primary target:

- Stuck task detection.
- Clearer timeout policy.
- Retry exhaustion diagnostics.
- Partial mission summaries.
- Recovery-safe mission state.
- Dependency diagnostics in API/CLI output.
- Structured mission/task event records suitable for future dashboard and memory work.
- More tests for bad plans and interrupted runs.
