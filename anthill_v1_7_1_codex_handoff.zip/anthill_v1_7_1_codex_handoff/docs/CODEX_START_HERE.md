# Codex Start Here

This folder is the Codex-ready handoff for **Operation ANTHILL v1.7.1 scheduler hardening checkpoint**.

v1.7.0 completed the Stage 1 scheduler foundation. v1.7.1 hardens that foundation with duplicate-ID validation parity, stronger full-result graph permissions, explicit cancellation-placeholder behavior, and focused scheduler regressions.

The next likely target is **v1.7.2 mission recovery, scheduler diagnostics, and structured event ledger**. Do not jump to v1.8/RAG/UI yet.

Before planning any implementation, read `docs/NORTH_STAR.md` and `docs/STAGE_BLUEPRINT.md`. They define the full long-range ANTHILL direction, stage order, anti-drift rules, and future modules that must not be accidentally designed out.

## Current Status

ANTHILL now has a standalone scheduler/task graph state machine wired through `Queen.run_mission`.

The important current files are:

- `anthill/runtime.py` - stable full runtime implementation and Queen integration.
- `anthill/core/scheduler.py` - scheduler/task graph state machine.
- `anthill/core/graph.py` - task graph export boundary.
- `tests/test_scheduler.py` - scheduler, graph, permission, migration, and Queen smoke tests.
- `tests/test_imports.py` - basic version/import regression.
- `tests/test_security_hardening.py` - security hardening regression tests.
- `docs/VERSION_STATE.md` - current checkpoint and validation baseline.
- `docs/SECURITY_RULES.md` - security invariants that must remain intact.
- `docs/V1_7_BUILD_SPEC.md` - completed v1.7.0 scheduler build target.
- `docs/V1_7_NOTES.md` - scheduler notes for v1.7.0/v1.7.1.
- `docs/NORTH_STAR.md` - long-range project constitution and stage map.
- `docs/STAGE_BLUEPRINT.md` - implementation boundaries for current and future stages.

## Validation Commands

From the repo root:

```bash
python -m py_compile $(find . -name '*.py' -print)
python -m pytest -q
python -m anthill --selftest
```

PowerShell equivalent:

```powershell
Get-ChildItem -Recurse -Filter *.py | ForEach-Object { python -m py_compile $_.FullName }
python -m pytest -q
python -m anthill --selftest
```

Expected v1.7.1 baseline:

```text
pytest: 20 passed
selftest: 15 checks passed, 0 failed, 0 warnings
```

## API Smoke Test

The API requires a strong token:

```powershell
$env:ANTHILL_API_TOKEN="replace-with-a-random-token-that-is-at-least-32-characters"
python -m anthill --api
```

Default API URL:

```text
http://127.0.0.1:8713/ui
```

Do not bind the unauthenticated API to `0.0.0.0` or a LAN/public address.

## Good Next Codex Prompt

```text
Read AGENTS.md, docs/CODEX_START_HERE.md, docs/NORTH_STAR.md, docs/STAGE_BLUEPRINT.md, docs/VERSION_STATE.md, docs/SECURITY_RULES.md, docs/V1_7_BUILD_SPEC.md, and docs/V1_7_NOTES.md. Then inspect anthill/runtime.py, anthill/core/scheduler.py, and tests/test_scheduler.py. Do not edit yet. Summarize the v1.7.1 scheduler hardening checkpoint, remaining recovery/diagnostic risks, and the smallest safe v1.7.2 plan.
```

## Good Implementation Prompt After Planning

```text
Implement ANTHILL v1.7.2 mission recovery, scheduler diagnostics, and structured event ledger. Preserve every security invariant in docs/SECURITY_RULES.md. Focus on stuck task detection, timeout policy, retry exhaustion diagnostics, partial mission summaries, recovery-safe mission state, dependency diagnostics, and structured mission/task events. Run py_compile, pytest, and python -m anthill --selftest. Report changed files and test results.
```
