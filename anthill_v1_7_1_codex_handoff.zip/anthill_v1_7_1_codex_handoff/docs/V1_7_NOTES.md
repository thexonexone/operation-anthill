# ANTHILL v1.7 Notes

v1.7.0 implements the Stage 1 scheduler/task graph foundation.
v1.7.1 hardens that foundation without expanding into UI, RAG, distributed workers, or new tool power.

## Implemented

- `TaskScheduler` in `anthill/core/scheduler.py`.
- Graph validation for missing dependencies, self-dependencies, self-parent links, cycles, and duplicate task IDs.
- Real task states: `pending`, `ready`, `blocked`, `running`, `complete`, `failed`, `skipped`, and `cancelled`.
- Failed dependency policy: downstream tasks become `skipped`, not `failed`.
- Retry policy: attempted failures increment `attempt_count`; exhausted retries become terminal `failed`.
- Duplicate task IDs are validation errors (`duplicate_task_id`) and are skipped so ambiguous IDs cannot silently overwrite scheduler lookup state.
- Public `validate_task_dependency_contract()` now detects duplicate task IDs in parity with `TaskScheduler`.
- SQLite schema version 7 with task lifecycle metadata columns.
- Queen integration through scheduler-owned ready/blocked/skipped transitions.
- Safe-by-default `task-graph-v2` export with no full task result summaries unless explicitly requested.
- `/graph` is metadata-first by default. `/graph?include_results=true` now requires `read_graph_results`.
- `/tasks` and mission detail may still show task result summaries because they are local-token development/diagnostic views; do not widen `/graph` to match them.
- `cancelled` exists only as a lifecycle placeholder in v1.7.1. Do not treat it as a complete cancellation pathway until a future version implements real cancellation behavior.
- Parallel ready-queue tests cover independent ready tasks while running tasks are excluded from the ready set.

## Preserved

- Queen remains the mission orchestrator.
- Ants remain the executors.
- v1.6.4 API and tool security invariants remain intact.
- No UI, RAG, distributed worker, plugin, or shell/file-write expansion was added.
- Legacy Queen dependency helpers are deprecated compatibility code; new scheduling work should stay in `TaskScheduler`.

## Validation

- `py_compile`: passed
- `pytest -q`: 20 passed
- `python -m anthill --selftest`: passed, 15 checks, 0 failed, 0 warnings

## Next

v1.7.2 should focus on mission recovery, scheduler diagnostics, and structured event/ledger work: stuck task detection, timeout policy, retry exhaustion diagnostics, partial mission summaries, recovery-safe mission state, dependency diagnostics, and tests for bad plans or interrupted runs.
