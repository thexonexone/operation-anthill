# ANTHILL Stage Blueprint

This is the implementation-facing companion to `docs/NORTH_STAR.md`.

Use this file when deciding what belongs in the current version versus what should wait. The purpose is to prevent Codex from skipping foundational layers or building later-stage ideas too early.

---

## Stage order summary

| Stage | Version band | Main build | Do not skip because |
|---|---:|---|---|
| 0 | v1.0-v1.6.4 | Secure baseline | Everything else depends on stable runtime and safety gates. |
| 1 | v1.7 | Scheduler/task graph | UI, swarm, and memory need real graph data. |
| 2 | v1.7.1 | Scheduler hardening checkpoint | Bad agent plans must not break missions. |
| 3 | v1.7.2/v1.8 prep | Mission recovery and ledger/events | Dashboard and memory need structured traces. |
| 4 | v1.8 | Memory/RAG | Reuse prior work without context pollution. |
| 5 | v1.8.1 | Pheromones | Make memory adaptive and visible. |
| 6 | v1.9 | Worker swarm runtime | Move from labels to real specialized execution. |
| 7 | v1.9.1 | Model router/local LLM | Keep cloud optional and task routing flexible. |
| 8 | v2.0 | Local OS harness | Turn prototype into durable local system. |
| 9 | v2.1 | Dashboard backend | UI needs stable API contracts. |
| 10 | v2.2 | Visual dashboard | Now visualize real mission data. |
| 11 | v2.3 | Project/codebase brain | Make ANTHILL useful for real repos. |
| 12 | v2.4 | Workflow automation | Repeatable operations with approvals. |
| 13 | v2.5 | Defensive ops/troubleshooting | Practical IT/homelab assistance, safely scoped. |
| 14 | v2.6 | Connectors/plugins | Extend without modifying core orchestration. |
| 15 | v3.0 | Distributed colony nodes | Scale across machines securely. |
| 16 | v3.1 | Guarded self-improvement | Learn better workflows with human approval. |
| 17 | v3.2+ | Hardware/edge/robotics | Add physical/edge interfaces safely. |
| 18 | v3.5+ | Personal operations OS | Mature Jarvis-like local operations layer. |

---

## Current implementation boundary

Current checkpoint: **v1.7.1 scheduler hardening checkpoint**.

The next implementation should focus on **Stage 3 / v1.7.2 mission recovery, scheduler diagnostics, and structured event ledger**.

Allowed now:

- stuck task detection,
- timeout policy,
- retry exhaustion diagnostics,
- partial mission summaries,
- recovery-safe mission state,
- dependency diagnostics,
- structured mission/task event records,
- scheduler hardening tests,
- docs/changelog updates.

Not allowed yet unless explicitly requested:

- large UI work,
- complex RAG/vector database implementation,
- distributed workers,
- autonomous shell expansion,
- plugin marketplace,
- robot/device control,
- major rewrite of the whole runtime.

---

## Stage dependency rules

### UI depends on task graph and event stream

Do not build the anthill/root visualization until the backend can emit real mission, task, ant, event, and pheromone data.

### Memory depends on clean mission records

Do not build advanced memory on unstructured logs. Memory should consume mission/task/tool/verifier records.

### Pheromones depend on memory

Do not make pheromones magical hidden prompts. They should be typed records with strength, confidence, scope, source, and decay.

### Swarm runtime depends on scheduler

Do not create parallel or distributed workers until the scheduler can correctly handle dependencies, retries, failures, and task states.

### Tool expansion depends on permission model

Do not add powerful tool access unless permissions, audit records, and failure handling are already in place.

### Distributed execution depends on local stability

Do not build remote worker nodes before local execution is safe, testable, and observable.

---

## When Codex is asked to add a feature

Before coding, classify the feature into one of these buckets:

1. **Current-stage feature** — implement now if safe.
2. **Future-stage placeholder** — add interface/docs only, no large implementation.
3. **Architecture violation** — refuse or propose a safer design.
4. **Security-sensitive feature** — require tests and preserve fail-closed defaults.
5. **UI-only request** — confirm whether backend data exists first; avoid fake logic.

Use this decision rule:

```text
If the feature bypasses Queen, scheduler, verifier, memory, or tool gates, it is probably wrong.
```

---

## Minimum done definition for any implementation stage

A stage is not complete unless:

- there are tests for the new behavior,
- existing tests still pass,
- `python -m anthill --selftest` still passes,
- docs explain the new boundary,
- security invariants are unchanged or strengthened,
- no runtime artifacts are committed,
- the implementation supports the next stage instead of blocking it.
