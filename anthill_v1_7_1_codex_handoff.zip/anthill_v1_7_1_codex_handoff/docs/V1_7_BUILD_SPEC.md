# ANTHILL v1.7 Build Spec — Advanced Scheduler / Task Graph

Status: completed in v1.7.0. This file is retained as the implementation record and regression target for future scheduler changes.

## Goal

v1.7 should turn ANTHILL from a mostly linear/parallel mission loop into a dependency-aware mission scheduler with a real task graph foundation.

This is a backend/runtime milestone, not a UI milestone.

## Do not build in v1.7

Do not build these yet:

- 3D anthill UI.
- RAG/vector memory.
- Distributed remote workers.
- Complex plugin marketplace.
- Cloud deployment layer.
- Autonomous shell/file write escalation.

Those come later.

## High-level execution model

```text
User request
  ↓
Queen
  ↓
Mission plan
  ↓
Task graph
  ↓
Dependency-aware scheduler
  ↓
Ant workers / tools
  ↓
Verifier checkpoints
  ↓
Memory + event ledger
  ↓
Final response
```

## Required concepts

### Task identity

Every scheduled task should have:

- `task_id`
- `mission_id`
- `title`
- `description`
- `task_type`
- `assigned_ant`
- `dependencies`
- `status`
- `attempt_count`
- `max_attempts`
- timestamps for created/started/completed/failed when practical
- summary/result/error fields where appropriate

Reuse existing `Task` model where possible. Avoid unnecessary schema churn.

### Task states

The scheduler should support a clear state machine. Suggested states:

```text
pending
blocked
ready
running
complete
failed
skipped
```

Existing status enums may differ. Prefer compatibility first. If adding enum values, update tests and any serializers/exporters.

### Dependency handling

A task is ready only when all required dependencies have completed successfully.

Rules:

- Missing dependency IDs should be detected.
- Cycles should be detected.
- Failed dependencies should block or skip dependent tasks according to explicit policy.
- Completed tasks should not rerun unless explicitly retried or reset.

### Retry handling

Retries should be explicit and bounded.

Rules:

- A failed task may retry until `max_attempts` is reached.
- Permission/security failures should not be retried blindly.
- Retry events should be logged.
- A task that exceeds retries becomes failed.

### Failure propagation

If a required task fails permanently:

- Direct dependents should become blocked/skipped/failed according to policy.
- The mission should produce a partial result summary rather than pretending success.
- The verifier should see failure context.

### Leases/timeouts

v1.7 does not need a full distributed lease system, but it should lay groundwork:

- identify running tasks,
- detect obviously stuck tasks if existing timeout infrastructure supports it,
- avoid duplicate execution of a running task.

### Task graph export

Graph export should be useful for the future UI.

Export should include:

- mission ID,
- nodes with task IDs, titles, assigned ants, task types, statuses, attempt counts,
- edges for dependencies,
- failure/blocking metadata when safe,
- schema version.

Do not include secrets or raw env values.

## Suggested implementation phases

### Phase 1 — scheduler model and pure tests

Create a scheduler class with pure logic first, likely in `anthill/core/scheduler.py` or in `anthill/runtime.py` with a re-export. It should accept tasks and compute ready/blocked/complete states without requiring model calls.

Add tests for:

- linear dependency order,
- fan-out/fan-in dependencies,
- missing dependency detection,
- cycle detection,
- ready queue calculation,
- failed dependency blocking,
- retry exhaustion.

### Phase 2 — integrate with Queen mission loop

Wire the scheduler into `Queen.run_mission` with minimal behavior drift.

Preserve:

- event logging,
- agent message ledger,
- source records,
- verifier pass,
- CLI output,
- API job behavior,
- self-test behavior.

### Phase 3 — graph export improvements

Update task graph export so API/UI can show scheduler state clearly.

Add tests that verify export shape and status transitions.

### Phase 4 — docs/version bump

Only after tests pass:

- bump version to `1.7.0`,
- update README,
- update `docs/VERSION_STATE.md`,
- update `CHANGELOG.md`,
- add a short `docs/V1_7_NOTES.md` if useful.

## Test expectations

Before declaring v1.7 complete:

```bash
python -m py_compile $(find . -name '*.py' -print)
python -m pytest -q
python -m anthill --selftest
```

Add v1.7 scheduler tests in `tests/test_scheduler.py` or equivalent.

## Acceptance criteria

v1.7 is complete when:

- task dependencies are enforced,
- cycle/missing dependency errors are detected,
- retries are bounded,
- failed dependencies do not silently pass,
- task graph export reflects states and edges,
- existing security tests still pass,
- self-test passes,
- no security invariant in `docs/SECURITY_RULES.md` is weakened.
