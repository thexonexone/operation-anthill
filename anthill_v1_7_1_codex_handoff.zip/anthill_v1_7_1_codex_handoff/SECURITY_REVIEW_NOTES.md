# ANTHILL v1.6.4 Security Review Notes

Reviewed and patched security-hardening revisions before moving toward v1.7.

## Fixes applied

1. **Auth rate limiter fixed**
   - Original behavior counted every authenticated API request against the auth limiter.
   - New behavior counts only failed authentication attempts, then clears the failure bucket after successful authentication.
   - Prevents accidental UI/API lockout during normal polling.

2. **Constant-time token comparison**
   - API token checks now use `secrets.compare_digest`.
   - Token validation now rejects empty tokens and tokens with leading/trailing whitespace.

3. **Unsafe API bind guard**
   - API refuses to start if `api_auth_enabled=false` while `api_host` is not loopback-only.
   - Safe loopback hosts: `127.0.0.1`, `localhost`, `::1`, and other loopback IP literals.

4. **SSRF/local URL filtering improved**
   - Replaced fragile string-prefix IP checks with `ipaddress` checks.
   - Blocks private, loopback, link-local, multicast, reserved, unspecified, localhost, `.localhost`, `.local`, malformed URLs, and non-http(s) schemes.
   - Filter is applied both inside the web search tool and again before source records are saved.

5. **SQLite permission hardening completed**
   - SQLite DB file is hardened after database creation, not only if it existed before workspace initialization.
   - Best-effort chmod now also covers WAL/SHM companion files when present.
   - Backup files continue to be chmod 600 where supported.

6. **Mission backup behavior corrected**
   - Pre-mission DB backup is now handled inside `Queen.run_mission`, so both CLI and API missions receive the same backup behavior.
   - Removed duplicate API-only backup call.

7. **Version/test drift fixed**
   - Import test now expects `1.6.4`.
   - `SelfTestReport.version` now uses `ANTHILL_VERSION` instead of hardcoded `1.6.3`.
   - Updated package/docs references that still said v1.6.3 where v1.6.4 was intended.

8. **Security regression tests added**
   - Added tests for token validation, outbound URL filtering, and auth failure limiter behavior.

## Validation performed

- `python -m py_compile $(find . -name '*.py' -print)`
- `python -m pytest -q` → 4 passed
- `python -m anthill --selftest` → PASSED, 15 checks passed, 0 failed, 0 warnings
- API app creation with a strong token succeeded.
- API app creation with auth disabled and `api_host=0.0.0.0` failed safely.

## Recommendation

This package is safe to treat as the corrected v1.6.4 checkpoint. Next step should be resuming the original path:

v1.6.4 reviewed → v1.6.4 local run check → v1.7 advanced scheduler/task graph.
