# ANTHILL Changelog

## v1.7.0

Advanced scheduler/task graph milestone.

Added:

- Standalone `TaskScheduler` in `anthill/core/scheduler.py` with dependency validation, cycle detection, ready/blocked transitions, skipped downstream tasks, bounded retries, and metadata-first graph export.
- Duplicate task ID validation with `duplicate_task_id`; ambiguous duplicate IDs are skipped and are not exposed through scheduler lookup state.
- Real task lifecycle statuses: `ready`, `blocked`, and `cancelled` in addition to the existing terminal states.
- Persisted task lifecycle fields for attempts, max attempts, failure/skip/block reasons, and failure/skip timestamps.
- Schema migration ledger version 7 for scheduler lifecycle metadata.
- Safe-by-default task graph export that omits full `result_summary` unless explicitly requested.
- Explicitly documented that `/graph` is metadata-first by default while `/tasks` and mission detail remain local-token diagnostic views that may show summaries.
- Scheduler regression tests for linear dependencies, fan-out/fan-in, blocked-to-ready transitions, failed dependency skipping, retries, retry exhaustion, graph validation, safe graph export, DB lifecycle columns, and a basic Queen mission smoke path.

Preserved:

- v1.6.4 API auth, rate limiting, security headers, docs-disabled default, SSRF filtering, DB backup/permission hardening, and tool gates.
- Queen remains the orchestrator; scheduler owns graph state and dependency decisions.

Validation:

- `py_compile`: passed
- `pytest -q`: 14 passed
- `python -m anthill --selftest`: passed, 15 checks, 0 failures, 0 warnings

## v1.6.4-security-reviewed-codex-handoff

Documentation-only handoff update for Codex continuation.

Added:

- `AGENTS.md` with standing coding-agent instructions.
- `docs/CODEX_START_HERE.md` with immediate orientation and commands.
- `docs/ANTHILL_CONTEXT.md` with project mission, architecture, and UI vision.
- `docs/VERSION_STATE.md` with the current checkpoint and next version target.
- `docs/SECURITY_RULES.md` with non-negotiable security invariants.
- `docs/V1_7_BUILD_SPEC.md` with the next implementation spec.
- `docs/ROADMAP.md` with the planned build sequence.
- `docs/CODEX_PROMPTS.md` with copy/paste prompts for Codex.
- `.gitignore` and `.env.example` for safer repo hygiene.

No runtime behavior was intentionally changed in this handoff update.

## v1.6.4-security-reviewed

Security-reviewed checkpoint before v1.7.

Highlights:

- Auth rate limiter counts failed auth attempts only.
- API token comparison uses constant-time comparison.
- API refuses unauthenticated non-loopback binding.
- SSRF/local URL filtering uses safer IP-aware logic.
- URL filtering applies before source records are saved.
- SQLite DB and backup permission hardening improved.
- Pre-mission DB backup unified through `Queen.run_mission`.
- v1.6.4 version drift cleaned up.
- Security regression tests added.

## v1.6.4 Codex North Star handoff

- Added `docs/NORTH_STAR.md` as the long-range ANTHILL project constitution.
- Added `docs/STAGE_BLUEPRINT.md` with implementation-facing stage boundaries and dependency rules.
- Updated Codex handoff docs so future coding agents preserve the full swarm OS harness direction, not just the immediate v1.7 target.
- No runtime behavior changed.
