# Codex Start Here

This folder is the Codex-ready handoff for **Operation ANTHILL v1.7.0 advanced scheduler/task graph**.

v1.7.0 completed the Stage 1 scheduler foundation. The next likely target is **v1.7.1 scheduler hardening and mission recovery**.

Before planning any implementation, read `docs/NORTH_STAR.md` and `docs/STAGE_BLUEPRINT.md`. They define the full long-range ANTHILL direction, stage order, anti-drift rules, and future modules that must not be accidentally designed out.

## Current Status

v1.7.0 adds a standalone scheduler/task graph state machine and wires `Queen.run_mission` through it.

The important current files are:

- `anthill/runtime.py` - stable full runtime implementation and Queen integration.
- `anthill/core/scheduler.py` - v1.7 scheduler/task graph state machine.
- `anthill/core/graph.py` - task graph export boundary.
- `tests/test_scheduler.py` - scheduler, graph, migration, and Queen smoke tests.
- `tests/test_imports.py` - basic version/import regression.
- `tests/test_security_hardening.py` - security hardening regression tests.
- `docs/VERSION_STATE.md` - current checkpoint and validation baseline.
- `docs/SECURITY_RULES.md` - security invariants that must remain intact.
- `docs/V1_7_BUILD_SPEC.md` - completed scheduler build target.
- `docs/NORTH_STAR.md` - long-range project constitution and stage map.
- `docs/STAGE_BLUEPRINT.md` - implementation boundaries for current and future stages.

## Validation Commands

From the repo root:

```bash
python -m py_compile $(find . -name '*.py' -print)
python -m pytest -q
python -m anthill --selftest
```

PowerShell equivalent:

```powershell
Get-ChildItem -Recurse -Filter *.py | ForEach-Object { python -m py_compile $_.FullName }
python -m pytest -q
python -m anthill --selftest
```

Expected v1.7.0 baseline:

```text
pytest: 14 passed
selftest: 15 checks passed, 0 failed, 0 warnings
```

## API Smoke Test

The API requires a strong token:

```powershell
$env:ANTHILL_API_TOKEN="replace-with-a-random-token-that-is-at-least-32-characters"
python -m anthill --api
```

Default API URL:

```text
http://127.0.0.1:8713/ui
```

Do not bind the unauthenticated API to `0.0.0.0` or a LAN/public address.

## Good Next Codex Prompt

```text
Read AGENTS.md, docs/CODEX_START_HERE.md, docs/NORTH_STAR.md, docs/STAGE_BLUEPRINT.md, docs/VERSION_STATE.md, docs/SECURITY_RULES.md, and docs/V1_7_BUILD_SPEC.md. Then inspect anthill/runtime.py, anthill/core/scheduler.py, and tests/test_scheduler.py. Do not edit yet. Summarize the v1.7 scheduler architecture, remaining risks, and the smallest safe v1.7.1 hardening plan.
```

## Good Implementation Prompt After Planning

```text
Implement ANTHILL v1.7.1 scheduler hardening and mission recovery. Preserve every security invariant in docs/SECURITY_RULES.md. Focus on stuck task detection, timeout policy, retry exhaustion diagnostics, partial mission summaries, recovery-safe mission state, dependency diagnostics, and tests for bad plans/interrupted runs. Run py_compile, pytest, and python -m anthill --selftest. Report changed files and test results.
```
