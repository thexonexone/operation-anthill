# ANTHILL Version State

## Current official checkpoint

**Version:** v1.7.0 advanced scheduler/task graph

**Purpose:** Stage 1 scheduler foundation: dependency-aware task graph execution, explicit lifecycle states, bounded retries, failure propagation, and safe graph export.

**Runtime package version:** `1.7.0` in `pyproject.toml` and `ANTHILL_VERSION`.

**Schema version:** `ANTHILL_SCHEMA_VERSION = 7`.

## What v1.7.0 is

v1.7.0 replaces the placeholder scheduler boundary with a standalone `TaskScheduler` in `anthill/core/scheduler.py` and wires `Queen.run_mission` through it.

The Queen still orchestrates mission setup, ant dispatch, logging, verification, memory, and final reports. The scheduler owns dependency resolution, graph validation, ready/blocked transitions, retry state, and skipped downstream tasks.

## Scheduler behavior included

- Real task lifecycle states: `pending`, `ready`, `blocked`, `running`, `complete`, `failed`, `skipped`, and `cancelled`.
- Structural dependency validation for missing dependencies, self-dependencies, self-parent links, and cycles.
- Dependency-aware ready queue calculation.
- Temporary `blocked` state for tasks waiting on dependencies.
- Terminal `skipped` state for tasks that cannot run because an upstream dependency failed or was skipped.
- Bounded retry handling with `attempt_count` and `max_attempts`.
- Terminal task failure metadata with `failure_reason`, `failure_type`, and `failed_at`.
- Skip/block metadata with `skipped_reason`, `skipped_at`, and `blocked_reason`.
- Metadata-first task graph export using `task-graph-v2`.
- Default graph export excludes full `result_summary` and raw task output.

## Security invariants preserved

v1.7.0 preserves the v1.6.4 security-reviewed controls:

- API token strength validation at API startup.
- Constant-time token comparison with `secrets.compare_digest`.
- Failed-auth rate limiter counts failed authentication attempts, not successful requests.
- Mission submission rate limiting.
- API startup protection: auth disabled cannot bind to `0.0.0.0` or another non-loopback host.
- Security headers on API responses.
- FastAPI docs/OpenAPI endpoints disabled by default.
- SSRF/local/private URL filtering with `ipaddress`-based checks.
- URL filtering before web results are returned and before source records are saved.
- SQLite DB and backup permission hardening.
- Pre-mission DB backup runs from `Queen.run_mission`, covering both CLI and API mission paths.
- Tool gates for shell, file writing, patch application, and web search remain fail-closed by default.

## Known design state

- `anthill/runtime.py` still contains most stable runtime implementation.
- `anthill/core/scheduler.py` now contains the v1.7 scheduler logic.
- Further extraction should wait until the scheduler behavior has more runtime mileage.
- The next stage should harden scheduler recovery, stuck-task diagnostics, timeout policy, and partial mission summaries.

## Baseline validation target

A clean v1.7.0 checkpoint should pass:

```bash
python -m py_compile $(find . -name '*.py' -print)
python -m pytest -q
python -m anthill --selftest
```

PowerShell equivalent:

```powershell
Get-ChildItem -Recurse -Filter *.py | ForEach-Object { python -m py_compile $_.FullName }
python -m pytest -q
python -m anthill --selftest
```

Validated baseline for this checkpoint:

```text
py_compile: passed
pytest: 14 passed
selftest: 15 checks passed, 0 failed, 0 warnings
```

## Next likely version

**v1.7.1 -- Scheduler hardening and mission recovery**

Primary target:

- Stuck task detection.
- Clearer timeout policy.
- Retry exhaustion diagnostics.
- Partial mission summaries.
- Recovery-safe mission state.
- Dependency diagnostics in API/CLI output.
- More tests for bad plans and interrupted runs.
