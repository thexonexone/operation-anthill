# Operation ANTHILL North Star

This document is the long-range product, architecture, and execution compass for **Operation ANTHILL**.

Codex must treat this document as a project constitution. When implementing any version, do not optimize only for the immediate ticket. Preserve the path toward the full system described here.

---

## 1. Core identity

**ANTHILL is a visible, local-first, swarm-intelligence operating harness for AI agents.**

It is not meant to become a normal chatbot, a loose script collection, or a UI mockup. The system should grow into an observable AI operating layer where a user gives an intent, a Queen agent converts that intent into a mission, specialized ants execute the work, a scheduler controls task flow, verifiers check the results, memory records what happened, and the UI makes the whole colony visible.

The final experience should feel closer to a **mission control system for a digital colony** than a prompt box.

The user should eventually be able to say something like:

```text
Build this feature, inspect the repo, identify risks, patch it, test it, explain what changed, remember what worked, and show me the task network live.
```

ANTHILL should then break that request into a visible mission with clear tasks, assigned ants, tool calls, verification steps, memory updates, and auditable results.

---

## 2. Non-negotiable product goal

The long-term goal is to build a **Jarvis-like local AI operations harness** with these properties:

1. **Local-first** — able to operate primarily on the user’s own machine, repo, files, tools, local models, and private memory.
2. **Swarm-based** — work is decomposed into specialized roles instead of one monolithic agent pretending to do everything.
3. **Observable** — every mission, task, ant, dependency, tool call, memory write, failure, and verification result should be inspectable.
4. **Secure by design** — shell, files, network access, API exposure, secrets, and remote actions must be gated, logged, and fail closed.
5. **Scalable** — the architecture should support more agents, more tools, more memory, more models, more workflows, and eventually distributed workers.
6. **Memory-bearing** — the colony should learn reusable patterns from previous missions without becoming unsafe, noisy, or ungrounded.
7. **Dashboard-ready** — backend data structures should eventually drive a 3D/live anthill-root visualization instead of needing a fake UI simulation.
8. **Extensible** — future ants, tools, skills, dashboards, model backends, connectors, and plugins should be addable without rewriting the core.

---

## 3. What ANTHILL must never drift into

Codex must avoid architecture drift toward these failure modes:

### 3.1 Generic chatbot drift

Do not reduce ANTHILL to a single chat loop with helper functions. The Queen, scheduler, ants, verifier, memory, and tool gates are core concepts, not decorative labels.

### 3.2 UI-first fake system drift

Do not build a beautiful dashboard that is not backed by real mission graph data. UI work must visualize real events, tasks, states, and memory records produced by the backend.

### 3.3 Unsafe automation drift

Do not make shell commands, file writes, patching, web calls, API exposure, or future integrations easier by bypassing security gates. Convenience must not weaken permissioning.

### 3.4 Cloud-only drift

Do not design core functionality so it only works through hosted/cloud services. Cloud models and APIs may be optional backends, but ANTHILL’s architecture should remain local-first.

### 3.5 Memory junk drawer drift

Do not store everything forever as vague text. Memory must become structured, searchable, scoped, compressible, and auditable.

### 3.6 Monolithic file drift

The current runtime is concentrated for stability, but the long-term direction is clean modules. Avoid adding major systems as tangled code inside one giant function or one giant file when a clear boundary exists.

### 3.7 Feature-stack-on-broken-core drift

Do not add big new features while tests, self-test, migrations, scheduler correctness, or security invariants are broken.

---

## 4. Permanent architectural pillars

Every version should preserve or move toward these pillars.

### 4.1 Queen

The Queen is the user-facing mission orchestrator.

Responsibilities:

- accept user intent,
- normalize the request into a mission,
- ask the planner for a task breakdown,
- send tasks into the scheduler,
- coordinate ant assignment,
- collect verified outputs,
- decide when a mission is complete,
- produce a final user-facing report,
- trigger memory updates.

The Queen should not become a dumping ground for every feature. The Queen owns orchestration, not every tool implementation.

### 4.2 Planner

The Planner converts a mission into tasks.

Responsibilities:

- decompose the mission,
- identify task dependencies,
- classify task types,
- estimate required tools,
- choose verification strategy,
- generate an initial task graph.

Future planners may use LLMs, templates, heuristics, or learned mission patterns.

### 4.3 Scheduler / Task Graph

The Scheduler is the mission traffic controller.

Responsibilities:

- maintain task states,
- enforce dependencies,
- detect cycles,
- select ready tasks,
- limit retries,
- handle blocked tasks,
- classify failures,
- emit graph events for the UI,
- expose task graph export.

This is the backbone for the future visible anthill UI.

### 4.4 Ant workers

Ants are specialized executors.

Initial and future ant classes may include:

- ResearchAnt,
- CoderAnt,
- BuilderAnt,
- FileAnt,
- VerifierAnt,
- MemoryAnt,
- SecurityAnt,
- ShellAnt,
- PlannerAnt,
- RefactorAnt,
- TestAnt,
- DocsAnt,
- APIAnt,
- UIAnt,
- OpsAnt,
- CyberDefenseAnt,
- HardwareAnt,
- HomeLabAnt,
- WorkflowAnt,
- ConnectorAnt,
- LocalModelAnt.

Ants should have clear skill profiles, tool permissions, input/output contracts, and audit trails.

### 4.5 Verifier

The Verifier checks that work is real, safe, and useful.

Responsibilities:

- check code compiles,
- run tests when available,
- validate task outputs,
- detect hallucinated claims,
- detect missing files or broken references,
- reject unsafe tool requests,
- produce a verification summary.

A mission should not be marked complete just because an ant produced text.

### 4.6 Memory and pheromones

ANTHILL memory should not be one flat note file. It should become layered.

Memory layers:

1. **Working memory** — temporary mission context.
2. **Mission ledger** — durable record of mission tasks, actions, outputs, errors, and final state.
3. **Pheromone memory** — compact signals about paths that succeeded, failed, were risky, or should be preferred/avoided.
4. **Semantic/RAG memory** — searchable facts, docs, project context, and prior solutions.
5. **Procedural memory** — reusable workflows and recipes.
6. **Skill memory** — knowledge tied to specific ants/tools.
7. **User preference memory** — durable preferences that improve future missions, only when safe and appropriate.

Pheromones should eventually influence planning and scheduling, but they must remain inspectable and correctable.

### 4.7 Tools and permissions

Tools are the colony’s hands. They must be gated.

Tool categories:

- file read,
- file write,
- patch apply,
- shell command,
- package manager,
- web search,
- browser/fetch,
- database,
- local model,
- repo/git,
- calendar/email/connectors,
- home lab/network tools,
- future robot/device control.

Every tool should have:

- permission level,
- default disabled/enabled policy,
- audit record,
- input validation,
- safe failure mode,
- tests for security-sensitive behavior.

### 4.8 API

The API should become the stable backend interface for CLI, UI, dashboard, and automation clients.

Long-term API responsibilities:

- submit missions,
- inspect mission state,
- stream task events,
- expose task graph data,
- manage memory entries,
- expose settings/safety profiles,
- report tool permissions,
- serve UI assets,
- support local-only default deployment.

Security must remain strict: auth on by default, loopback host by default, safe headers, no open docs by default, no non-loopback unauthenticated exposure.

### 4.9 UI / dashboard

The UI is not just a skin. It is the visible nervous system.

Long-term UI concept:

- central Queen/core node,
- mission tunnels branching into task paths,
- ants moving through tasks,
- digital pheromone trails showing success/failure/priority/confidence,
- live logs and verification gates,
- zoomable root/anthill structure,
- searchable mission history,
- memory graph,
- tool permission panel,
- replayable mission timelines.

The UI should be built after the backend produces real task graph and event data.

---

## 5. Stage-by-stage execution path

The version numbers below are guidance, not permanent law. The sequence matters more than the exact labels.

### Stage 0 — Foundation and checkpoint hardening

**Approximate versions:** v1.0 through v1.6.4  
**Current status:** completed at v1.6.4 security-reviewed checkpoint.

Purpose:

- create the base ANTHILL runtime,
- establish Queen-led mission execution,
- create initial ants and tools,
- add CLI/API basics,
- add SQLite memory foundation,
- add security gates,
- add self-tests,
- stop before hidden issues compound.

Exit criteria:

- imports compile,
- tests pass,
- self-test passes,
- API auth is strong,
- local/private URL filtering exists,
- DB backups and permissions are hardened,
- dangerous tools are gated.

Codex instruction:

Do not revisit this stage by rewriting everything. Preserve it as the stable baseline unless a specific bug is found.

---

### Stage 1 — Dependency-aware scheduler and task graph

**Approximate version:** v1.7
**Current status:** completed in v1.7.0.

Purpose:

Transform ANTHILL from a simple sequence runner into a real mission graph system.

Must build:

- task IDs,
- task states,
- parent/child task relationships,
- dependency lists,
- ready/blocked/running/completed/failed/skipped states,
- retry counters,
- failure reasons,
- graph export,
- basic event emission,
- scheduler tests.

Why it matters:

The future UI, swarm runtime, memory, and automation system all depend on a reliable task graph.

Exit criteria:

- dependency ordering works,
- blocked tasks do not run,
- failed dependencies propagate cleanly,
- cycles/dead dependencies are detected,
- retries are bounded,
- graph export is deterministic,
- existing CLI/API behavior is not broken.

Do not add yet:

- full UI,
- distributed workers,
- complex RAG,
- autonomous shell execution.

---

### Stage 2 — Scheduler hardening and mission recovery

**Approximate version:** v1.7.1

Purpose:

Make the scheduler resilient under bad plans, partial failures, interrupted runs, and retry exhaustion.

Must build:

- stuck task detection,
- timeout policy,
- partial mission summaries,
- failed task classification,
- recovery-safe mission state,
- dependency diagnostics,
- clearer run reports,
- more scheduler regression tests.

Why it matters:

A swarm harness must survive imperfect agents. Bad tasks should not collapse the whole system silently.

Exit criteria:

- no infinite loops,
- no silent task loss,
- failures are visible,
- retry exhaustion is understandable,
- mission ledger remains consistent.

---

### Stage 3 — Structured mission ledger and event stream

**Approximate version:** v1.7.2 or v1.8 prep

Purpose:

Record missions as structured timelines, not just final outputs.

Must build:

- mission event schema,
- task event schema,
- tool call records,
- verifier records,
- graph snapshots,
- mission replay data,
- API endpoints for mission status/history.

Why it matters:

The dashboard needs real mission telemetry. Memory also needs structured data to learn from.

Exit criteria:

- every mission has a durable trace,
- every task state transition is recordable,
- mission replay/export is possible,
- sensitive data is not accidentally logged.

---

### Stage 4 — Memory/RAG foundation

**Approximate version:** v1.8

Purpose:

Move from simple durable records into useful recall.

Must build:

- searchable mission memory,
- scoped memory entries,
- document/project ingestion boundary,
- embeddings/vector store adapter boundary,
- memory write policies,
- memory summarization,
- memory deletion/correction path,
- success/failure recall.

Why it matters:

ANTHILL should learn from past missions without polluting future context.

Exit criteria:

- prior mission lessons can be retrieved,
- memory entries are typed/scoped,
- memory can be inspected,
- memory can be pruned/corrected,
- no uncontrolled secret storage.

---

### Stage 5 — Digital pheromone system

**Approximate version:** v1.8.1

Purpose:

Turn memory into lightweight routing signals.

Must build:

- success pheromones,
- failure pheromones,
- risk pheromones,
- confidence pheromones,
- decay/aging rules,
- reinforcement rules,
- human override/correction,
- planner/scheduler read access.

Why it matters:

Pheromones are how ANTHILL becomes adaptive like a colony rather than just archival like a database.

Exit criteria:

- pheromones influence plans only through explicit, inspectable rules,
- stale signals decay,
- bad signals can be corrected,
- UI can eventually visualize pheromone trails.

---

### Stage 6 — Worker swarm runtime

**Approximate version:** v1.9

Purpose:

Move from conceptual ants to a real worker system.

Must build:

- worker registry,
- skill profiles,
- task-to-ant routing,
- worker queues,
- optional parallel execution policy,
- handoff protocol,
- worker performance metrics,
- worker permission scopes.

Why it matters:

The system cannot scale if every task is handled the same way by one generic executor.

Exit criteria:

- tasks route to appropriate ants,
- ants declare skills and permissions,
- queue behavior is deterministic,
- parallelism is optional and bounded,
- tool access follows ant permission scopes.

---

### Stage 7 — Model router and local LLM support

**Approximate version:** v1.9.1 or v2.0 prep

Purpose:

Allow different tasks to use different model backends.

Must build:

- model provider abstraction,
- local model adapter boundary,
- remote API adapter boundary,
- task-type routing,
- cost/performance tracking,
- context window awareness,
- fallback model policy,
- no-provider dry-run path.

Why it matters:

ANTHILL should eventually run with cloud models, local Ollama-style models, or a mixed stack without rewiring the whole system.

Exit criteria:

- model choice is configurable,
- local-first remains possible,
- secrets are not logged,
- model failures degrade gracefully.

---

### Stage 8 — Local ANTHILL OS harness

**Approximate version:** v2.0

Purpose:

Establish ANTHILL as a stable local operating harness rather than a prototype script.

Must build:

- clean package boundaries,
- stable CLI commands,
- stable API surface,
- config profiles,
- permission profiles,
- durable mission/memory store,
- startup diagnostics,
- health checks,
- export/import paths,
- backup/restore path.

Why it matters:

This is the first milestone where ANTHILL should feel like a real local system.

Exit criteria:

- install/run path is documented,
- fresh setup works,
- self-test is meaningful,
- API/CLI behave consistently,
- data survives restarts,
- backup/restore is tested.

---

### Stage 9 — Dashboard-ready backend

**Approximate version:** v2.1

Purpose:

Prepare the backend for a real UI without building a fake frontend first.

Must build:

- mission status endpoint,
- task graph endpoint,
- event stream endpoint,
- memory summary endpoint,
- tool permission endpoint,
- health/status endpoint,
- UI-safe event DTOs,
- redaction rules.

Why it matters:

The future anthill visualization must consume real backend data.

Exit criteria:

- a UI can subscribe to mission updates,
- task graph data is stable,
- sensitive data is redacted,
- API tests cover UI-facing contracts.

---

### Stage 10 — Visual anthill/root dashboard

**Approximate version:** v2.2

Purpose:

Create the visible mission-control UI.

Must build:

- Queen/core node visualization,
- task tunnel graph,
- ant worker nodes,
- live task state changes,
- pheromone trail overlays,
- log/detail drawer,
- mission replay,
- memory graph view,
- tool permission/safety panel.

Visual direction:

- central core network feeling,
- 3D anthill/root system metaphor,
- zoom in/out from mission overview to individual ant actions,
- dense but readable root/tunnel structure,
- live status pulses or trails for task flow.

Exit criteria:

- UI displays real mission data,
- no fake placeholder mission logic,
- UI does not require weakening API security,
- user can inspect why a mission succeeded or failed.

---

### Stage 11 — Project/codebase brain

**Approximate version:** v2.3

Purpose:

Make ANTHILL useful for long-running software projects.

Must build:

- repo map ingestion,
- file/module summaries,
- dependency awareness,
- changelog awareness,
- test inventory,
- code ownership notes,
- architectural decision records,
- pull request/diff review workflow.

Why it matters:

ANTHILL should eventually help build itself and other codebases without losing architectural continuity.

Exit criteria:

- project structure can be summarized,
- changed files can be reasoned about,
- tests can be associated with components,
- Codex/ANTHILL handoff docs remain synchronized.

---

### Stage 12 — Workflow automation layer

**Approximate version:** v2.4

Purpose:

Allow ANTHILL to run repeatable workflows safely.

Must build:

- workflow definitions,
- runbooks,
- approval checkpoints,
- scheduled/manual execution modes,
- parameterized missions,
- rollback steps,
- audit logs.

Examples:

- repo maintenance,
- test-and-patch loop,
- document ingestion,
- homelab inventory scan,
- backup verification,
- routine report generation.

Exit criteria:

- workflows are explicit,
- dangerous steps require approval,
- every run is logged,
- workflow failures produce recovery guidance.

---

### Stage 13 — Defensive ops and troubleshooting mode

**Approximate version:** v2.5

Purpose:

Support legitimate IT, homelab, and defensive troubleshooting workflows.

Allowed direction:

- diagnostics,
- configuration review,
- log analysis,
- patch guidance,
- local network inventory with permission,
- backup checks,
- service health checks,
- defensive security posture review.

Do not build:

- malware,
- credential theft,
- stealth/persistence tooling,
- unauthorized scanning,
- exploit automation against third-party systems.

Exit criteria:

- defensive scope is explicit,
- permission prompts are clear,
- logs are auditable,
- dangerous capabilities remain gated.

---

### Stage 14 — Connector and plugin ecosystem

**Approximate version:** v2.6

Purpose:

Allow safe extension into external systems.

Potential connectors:

- Git providers,
- issue trackers,
- local files/NAS,
- email/calendar with permission,
- documentation systems,
- home lab services,
- monitoring systems,
- local model servers.

Must build:

- plugin manifest,
- permission declarations,
- sandbox/limits,
- connector health checks,
- secret storage rules,
- connector-specific tests.

Exit criteria:

- connectors can be added without modifying the Queen,
- permissions are visible,
- secrets are protected,
- connector failures do not crash the colony.

---

### Stage 15 — Distributed colony nodes

**Approximate version:** v3.0

Purpose:

Allow ANTHILL to coordinate work across multiple machines or worker nodes.

Must build:

- node identity,
- node capability profiles,
- secure local-network transport,
- task leasing,
- heartbeat/health checks,
- result verification,
- failure recovery,
- trust boundaries.

Why it matters:

A future rack/homelab setup may run different workers on different machines, such as GPU nodes, storage nodes, test runners, or local LLM boxes.

Exit criteria:

- no unauthenticated remote execution,
- node permissions are explicit,
- failed nodes do not lose missions,
- task results remain verifiable.

---

### Stage 16 — Advanced learning and self-improvement guardrails

**Approximate version:** v3.1

Purpose:

Let ANTHILL improve its own workflows without uncontrolled self-modification.

Must build:

- post-mission reviews,
- recurring failure detection,
- suggested workflow improvements,
- human-approved rule updates,
- test-before-adopt policy,
- rollbackable configuration changes.

Do not build:

- unsupervised self-modifying code,
- hidden prompts,
- unreviewed permission escalation,
- silent memory rewrites.

Exit criteria:

- improvements are proposed, not silently applied,
- user can inspect and approve changes,
- changes can be rolled back,
- tests guard learned workflows.

---

### Stage 17 — Hardware, robotics, and edge interfaces

**Approximate version:** v3.2+

Purpose:

Prepare for future physical/edge integrations without compromising safety.

Possible directions:

- local voice interface,
- cyberdeck dashboard mode,
- robot/droid display mode,
- sensor ingestion,
- homelab rack status display,
- local device control with strict permissions.

Hard rules:

- physical actions require explicit permission,
- device control must be sandboxed,
- safety-critical actions need confirmation,
- logs must record who/what triggered actions.

Exit criteria:

- ANTHILL can observe devices safely,
- control actions are permissioned,
- dangerous automation is not implicit.

---

### Stage 18 — Personal operations OS

**Approximate version:** v3.5+

Purpose:

Make ANTHILL feel like a personalized operations layer for projects, home lab, coding, documents, automations, and planning.

Capabilities may include:

- project dashboard,
- mission history,
- memory search,
- recurring workflow checks,
- local file/doc assistant,
- coding harness,
- homelab assistant,
- secure automation approvals,
- voice/dashboard interface,
- long-range task planning.

Exit criteria:

- the user can see what ANTHILL knows,
- the user can correct memory,
- the user can approve/deny actions,
- the system remains local-first and secure.

---

## 6. Cross-stage data contracts to preserve

Codex should design new features so they can later support these durable concepts.

### 6.1 Mission

A mission should eventually include:

- mission ID,
- user request,
- normalized objective,
- created timestamp,
- status,
- priority,
- safety profile,
- task graph,
- events,
- outputs,
- verification summary,
- memory writes,
- final report.

### 6.2 Task

A task should eventually include:

- task ID,
- mission ID,
- title,
- description,
- type,
- assigned ant/skill,
- dependencies,
- status,
- retry count,
- timeout policy,
- tool permissions,
- input payload,
- output payload,
- verification result,
- failure reason,
- timestamps.

### 6.3 Ant

An ant should eventually include:

- ant ID/type,
- skill profile,
- allowed tools,
- model/backend preference,
- input schema,
- output schema,
- performance stats,
- failure stats.

### 6.4 Pheromone

A pheromone should eventually include:

- scope,
- signal type,
- strength,
- confidence,
- source mission/task,
- created timestamp,
- decay policy,
- human override flag.

### 6.5 Tool call

A tool call should eventually include:

- tool name,
- task ID,
- permission level,
- sanitized arguments,
- status,
- result summary,
- error summary,
- timestamp,
- redaction status.

---

## 7. Version gate checklist

Before any version is declared complete, Codex should verify:

1. Code compiles.
2. Unit tests pass.
3. Self-test passes.
4. Security invariants remain intact.
5. Changelog/version docs are updated.
6. New behavior has tests.
7. Runtime artifacts are not committed.
8. Public CLI/API behavior is preserved unless intentionally versioned.
9. Mission/task/memory data structures still move toward the North Star.
10. No feature was added by bypassing Queen, scheduler, verifier, memory, or tool gates.

---

## 8. Development philosophy

Build ANTHILL like a real OS harness:

- small stable layers,
- explicit interfaces,
- testable contracts,
- fail-closed security,
- observable execution,
- durable memory,
- reversible changes,
- clear version checkpoints.

The goal is not to rush to a flashy demo. The goal is to build a strong skeleton that can eventually scale into a visible, adaptive, local AI colony.
