# ANTHILL Roadmap

This is the compact roadmap. For the detailed project constitution and stage descriptions, read:

- `docs/NORTH_STAR.md`
- `docs/STAGE_BLUEPRINT.md`

## North Star

ANTHILL is a visible, local-first swarm-intelligence operating harness. The project should grow from a secure local mission runner into a Jarvis-like operations layer with Queen orchestration, dependency-aware task graphs, specialized ants, verifier gates, structured memory, digital pheromones, permissioned tools, optional local model routing, dashboard-ready telemetry, and eventually a live anthill/root-network UI.

## Stage sequence

```text
Stage 0  / v1.0-v1.6.4  Secure baseline and stability checkpoint
Stage 1  / v1.7          Dependency-aware scheduler and task graph
Stage 2  / v1.7.1        Scheduler hardening and mission recovery
Stage 3  / v1.7.2+       Structured mission ledger and event stream
Stage 4  / v1.8          Memory/RAG foundation
Stage 5  / v1.8.1        Digital pheromone system
Stage 6  / v1.9          Worker swarm runtime
Stage 7  / v1.9.1        Model router and local LLM support
Stage 8  / v2.0          Local ANTHILL OS harness
Stage 9  / v2.1          Dashboard-ready backend
Stage 10 / v2.2          Visual anthill/root dashboard
Stage 11 / v2.3          Project/codebase brain
Stage 12 / v2.4          Workflow automation layer
Stage 13 / v2.5          Defensive ops and troubleshooting mode
Stage 14 / v2.6          Connector and plugin ecosystem
Stage 15 / v3.0          Distributed colony nodes
Stage 16 / v3.1          Guarded self-improvement
Stage 17 / v3.2+         Hardware, robotics, and edge interfaces
Stage 18 / v3.5+         Personal operations OS
```

## Current checkpoint

Current version: **v1.7.0 advanced scheduler/task graph**.

Current priority: harden scheduler recovery and diagnostics without weakening API security, tool gates, DB hardening, URL filtering, or graph export safety.

## Immediate next stage: v1.7.1

Harden the scheduler/task graph foundation:

- stuck task detection,
- timeout policy,
- retry exhaustion diagnostics,
- partial mission summaries,
- recovery-safe mission state,
- dependency diagnostics,
- tests for bad plans and interrupted runs,
- continued preservation of existing CLI/API/self-test behavior.

## Sequencing rule

Do not build later stages by bypassing earlier stages.

Examples:

- Do not build the UI before real task graph/event data exists.
- Do not build pheromones before structured memory exists.
- Do not build distributed workers before local scheduler correctness exists.
- Do not add powerful tool access before permission/audit gates exist.
- Do not add self-improvement before rollback, tests, and human approval exist.

## Anti-drift rule

If a change makes ANTHILL more like a generic chatbot, a fake UI demo, an unsafe automation script, or a cloud-only product, redesign the change.
