# ANTHILL Core v1.7.0 Architecture

v1.7.0 is the scheduler/task graph checkpoint built on the v1.6.4 security-reviewed baseline.

## Rule

Preserve behavior first, split implementation second.

The stable runtime is still mostly preserved in `anthill/runtime.py`. Subsystem modules expose public boundaries so future versions can move code out of runtime one subsystem at a time without breaking imports.

## Current Split

- `anthill.config` owns configuration and safety profile boundaries.
- `anthill.models` re-exports Pydantic contracts.
- `anthill.core.scheduler` owns dependency validation, ready/blocked/skipped transitions, bounded retries, and graph export for live task objects.
- `anthill.core.graph` exposes task graph contracts.
- `anthill.core.queen` exposes Queen orchestration.
- `anthill.ants` owns specialized agent role boundaries.
- `anthill.memory` owns SQLite memory, migrations, pheromones, and later vector/RAG memory boundaries.
- `anthill.tools` owns controlled external capabilities.
- `anthill.api` owns FastAPI, jobs, permissions, and schemas.
- `anthill.ui` will eventually own dashboard assets.

## Scheduler Boundary

The Queen plans missions, records events, dispatches ants, finalizes results, and saves memory. The scheduler owns task graph state:

- dependency validation,
- cycle/missing dependency detection,
- `ready` and `blocked` transitions,
- downstream `skipped` propagation,
- attempt counting,
- bounded retries,
- terminal failure metadata,
- safe graph export.

Do not move scheduler logic back into `Queen.run_mission`. Queen should ask the scheduler what can run next and log the resulting transitions.

## Next Target

v1.7.1 should harden mission recovery around stuck tasks, timeout policy, retry exhaustion diagnostics, partial mission summaries, recovery-safe state, and dependency diagnostics.
