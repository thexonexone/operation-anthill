# Useful Codex Prompts for ANTHILL

## 1. Initial Orientation

```text
Read AGENTS.md, docs/CODEX_START_HERE.md, docs/NORTH_STAR.md, docs/STAGE_BLUEPRINT.md, docs/VERSION_STATE.md, docs/SECURITY_RULES.md, docs/V1_7_BUILD_SPEC.md, and docs/V1_7_NOTES.md. Inspect anthill/runtime.py, anthill/core/scheduler.py, and tests/test_scheduler.py, but do not edit yet. Summarize where ANTHILL currently stands and propose the smallest safe v1.7.1 hardening plan.
```

## 2. Baseline Validation

```text
Run the repo baseline checks: py_compile for all Python files, python -m pytest -q, and python -m anthill --selftest. Do not change code. Report failures exactly and suggest the smallest fixes only if something fails.
```

## 3. v1.7.1 Implementation

```text
Implement ANTHILL v1.7.1 scheduler hardening and mission recovery. Preserve every security invariant in docs/SECURITY_RULES.md. Focus on stuck task detection, timeout policy, retry exhaustion diagnostics, partial mission summaries, recovery-safe mission state, dependency diagnostics, and tests for bad plans/interrupted runs. Run py_compile, pytest, and selftest. Report changed files and test results.
```

## 4. Security Review After Patch

```text
Review the current working tree as a security reviewer. Focus on API auth, rate limiting, URL filtering/SSRF, file/shell/patch tool gates, DB permissions, scheduler retry/failure behavior, graph export leakage, and accidental secret leakage. Do not change code unless you find a concrete issue. Provide findings ranked by severity.
```

## 5. Diff Explanation

```text
Explain the current diff file-by-file. Separate behavior changes, test changes, docs changes, and risks. Identify anything that should be reviewed manually before calling this version complete.
```

## 6. Version Finalization

```text
If all tests pass and the implementation matches the requested version scope, finalize version metadata. Update README, docs/VERSION_STATE.md, CHANGELOG.md, and any version constants. Do not change runtime behavior during version finalization.
```

## North Star Alignment Prompt

```text
Read docs/NORTH_STAR.md and docs/STAGE_BLUEPRINT.md. Summarize the long-term ANTHILL goal, the current stage, the next three stages, and any anti-drift rules relevant to the change I am asking for. Do not edit files yet.
```

## Future-Stage Request Handling Prompt

```text
Classify this requested feature against docs/NORTH_STAR.md and docs/STAGE_BLUEPRINT.md. Tell me whether it belongs in the current stage, should be a future-stage placeholder, violates the architecture, or requires security-sensitive handling. Do not implement until the classification is clear.
```
