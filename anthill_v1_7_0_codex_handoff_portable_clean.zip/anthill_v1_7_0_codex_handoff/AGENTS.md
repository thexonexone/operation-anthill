# ANTHILL Agent Instructions

This repository is **Operation ANTHILL**.

ANTHILL is a local-first swarm-intelligence framework for AI agents. A Queen agent receives a user request, turns it into a mission, assigns specialized ant workers, records compact communication, verifies outputs, and stores reusable memory. The long-term goal is an observable AI OS harness with a future dashboard that visualizes missions like a living anthill/root network.

## Current Checkpoint

- Current version: **v1.7.0 advanced scheduler/task graph**.
- Current purpose: Stage 1 scheduler foundation over the v1.6.4 security-reviewed baseline.
- Runtime status: the stable implementation remains concentrated in `anthill/runtime.py`, with scheduler/task graph logic implemented in `anthill/core/scheduler.py`.
- Next version target: **v1.7.1 scheduler hardening and mission recovery**.

## Authoritative Handoff Docs

Read these before making code changes:

1. `docs/CODEX_START_HERE.md` - immediate handoff and working commands.
2. `docs/NORTH_STAR.md` - project constitution, end-state, anti-drift rules, and staged future.
3. `docs/STAGE_BLUEPRINT.md` - implementation-facing stage boundaries and dependency rules.
4. `docs/VERSION_STATE.md` - exact checkpoint status and validation baseline.
5. `docs/SECURITY_RULES.md` - security invariants that must not be weakened.
6. `docs/V1_7_BUILD_SPEC.md` - completed v1.7 scheduler implementation target.
7. `docs/ANTHILL_CONTEXT.md` - project vision and architecture direction.
8. `docs/ROADMAP.md` - compact version path after v1.7.

## North Star Rule

Every code change must preserve the direction described in `docs/NORTH_STAR.md`. ANTHILL is being built as a visible, local-first, swarm-intelligence operating harness, not as a generic chatbot, not as a UI-only demo, and not as an unsafe automation script.

When a requested change conflicts with the North Star, prefer the design that strengthens these long-term pillars: Queen orchestration, dependency-aware scheduling, specialized ants, verifier gates, structured memory, pheromone learning, permissioned tools, local-first operation, and observable UI-ready execution data.

## Non-Negotiable Development Rules

- Preserve the current v1.7.0 behavior unless a requested version explicitly changes it.
- Prefer small, reviewable patches over large rewrites.
- Do not remove security checks to make tests pass.
- Do not silently change public CLI/API command names, response shapes, schemas, or defaults.
- Do not hardcode secrets, tokens, usernames, absolute local paths, or machine-specific values.
- Do not commit runtime artifacts: `.anthill/`, DB files, logs, exports, backups, virtualenvs, caches, `.env`, or generated zips.
- Keep API auth enabled by default and keep API host loopback by default.
- Keep file writing, patch application, shell access, and web search disabled by default unless the user intentionally enables a safety profile.
- Add or update tests for every security-sensitive or scheduler-sensitive change.
- Run tests before declaring a checkpoint complete.

## Security Invariants

Do not weaken these controls:

- Strong API token validation for API startup.
- Constant-time API token comparison with `secrets.compare_digest`.
- Failed-auth rate limiting that does not punish successful authenticated requests.
- Mission submission rate limiting.
- Refusal to run unauthenticated API on non-loopback hosts.
- Disabled FastAPI `/docs`, `/redoc`, and `/openapi.json` by default.
- Security headers middleware.
- SSRF/local/private URL filtering before agents see or save source records.
- SQLite DB and backup permission hardening.
- Automatic DB backup at mission start for both CLI and API paths.
- Tool gates for shell, file writes, patch application, and web search.
- Safe-by-default graph export that does not leak raw task output or full result summaries.

## Working Style For Codex

When asked to implement a version:

1. Read the relevant docs listed above.
2. Inspect the current code before editing.
3. Produce a brief implementation plan.
4. Make the smallest viable patch.
5. Run:
   - `python -m py_compile $(find . -name '*.py' -print)` on Linux/macOS/WSL, or the PowerShell equivalent.
   - `python -m pytest -q`.
   - `python -m anthill --selftest`.
6. Report changed files, test results, and any unresolved risks.

## Architecture Boundaries

The intended long-term package split is:

- `anthill.config` - configuration and safety profiles.
- `anthill.models` - Pydantic contracts and schema envelopes.
- `anthill.core` - Queen, Planner, scheduler, graph, communication, self-test.
- `anthill.ants` - specialized ant roles.
- `anthill.memory` - SQLite memory, migrations, pheromones, later vector/RAG memory.
- `anthill.tools` - permissioned external capabilities.
- `anthill.api` - FastAPI, jobs, permissions, schemas.
- `anthill.ui` - dashboard assets and future visual layer.

Do not force a full split in one patch. For v1.7.1, harden scheduler recovery and diagnostics with minimal disruption.

## Immediate Next Task After This Handoff

Begin **v1.7.1 scheduler hardening and mission recovery**. Use `docs/NORTH_STAR.md` and `docs/STAGE_BLUEPRINT.md` to avoid skipping foundational recovery/event work before UI, RAG, distributed workers, local model routing, plugin systems, or robotics/device control.
