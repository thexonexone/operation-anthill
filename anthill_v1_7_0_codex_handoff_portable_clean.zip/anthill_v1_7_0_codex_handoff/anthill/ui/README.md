# ANTHILL UI boundary

v1.7.0 preserves the existing local dashboard served by `anthill.runtime` at `/ui`.
Future UI work can move the inline dashboard into this package as separate
HTML/CSS/JS files without changing the API layer.
