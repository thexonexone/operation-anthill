"""Configuration boundary for ANTHILL.

Currently re-exports the stable v1.7.0 runtime config. Future versions can move
implementation here without changing callers.
"""
from .runtime import (
    AnthillConfig,
    ANTHILL_CONFIG,
    ANTHILL_PATHS,
    ANTHILL_CONFIG_PATH,
    ANTHILL_WORKSPACE_ROOT,
    ANTHILL_DB_PATH,
    ANTHILL_VERSION,
    ANTHILL_SCHEMA_VERSION,
    ENABLE_WEB_SEARCH,
    ENABLE_API_AUTH,
    ENABLE_PATCH_APPLICATION,
    ENABLE_FILE_WRITING,
    ENABLE_SHELL_TOOL,
    API_HOST,
    API_PORT,
    API_AUTH_TOKEN,
    API_PERMISSIONS,
    load_anthill_config,
    ensure_anthill_workspace,
)

__all__ = [name for name in globals() if not name.startswith("_")]
