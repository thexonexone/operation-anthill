# ANTHILL Core v1.6.3 Architecture

v1.6.3 is a project-structure checkpoint before the v1.7 scheduler.

## Rule

Preserve behavior first, split implementation second.

The stable runtime is currently preserved in `anthill/runtime.py`. Subsystem
modules re-export the public boundaries so future versions can move code out of
runtime one subsystem at a time without breaking imports.

## Long-term split

- `anthill.config` owns configuration and safety profiles.
- `anthill.models` owns Pydantic contracts.
- `anthill.core` owns Queen, Planner, communication, graph, scheduler, self-test.
- `anthill.ants` owns specialized agent roles.
- `anthill.memory` owns SQLite memory, migrations, pheromones, and later vector/RAG memory.
- `anthill.tools` owns controlled external capabilities.
- `anthill.api` owns FastAPI, jobs, permissions, and schemas.
- `anthill.ui` will own dashboard assets.

## v1.7 target

`anthill.core.scheduler` is reserved for the advanced scheduler. v1.7 should add
TaskScheduler, queue items, priorities, leases, retries, blocked states, and graph
validation there, then wire Queen to it.
