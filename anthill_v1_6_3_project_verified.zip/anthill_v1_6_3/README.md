# ANTHILL Core v1.6.3

Project Structure + Module Split checkpoint.

This version keeps the v1.6.2 runtime behavior stable while moving ANTHILL into a
package layout so v1.7 can add the advanced scheduler cleanly.

## Install dependencies

```powershell
pip install pydantic rich requests fastapi uvicorn
```

Optional local model:

```powershell
ollama pull llama3.1:8b
```

## Run self-test

```powershell
python -m anthill --selftest
```

or:

```powershell
python run_anthill.py --selftest
```

## Run CLI

```powershell
python -m anthill
```

## Run API/UI

```powershell
$env:ANTHILL_API_TOKEN="your-local-secret-token"
python -m anthill --api
```

Open:

```text
http://127.0.0.1:8713/ui
```

## Important

v1.6.3 is intentionally not the scheduler revision. It creates stable import
paths and project boundaries first:

```text
anthill/core/scheduler.py
```

v1.7 should implement the advanced scheduler there.
