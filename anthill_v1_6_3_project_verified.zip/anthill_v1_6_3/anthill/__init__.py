"""ANTHILL Core v1.6.3 package.

v1.6.3 is the project-structure checkpoint. The full stable runtime remains in
``anthill.runtime`` for behavior preservation, while subsystem modules re-export
clear public boundaries that v1.7+ can replace with native implementations.
"""

from .runtime import ANTHILL_VERSION, AnthillConfig, Queen, SQLiteMemory

__all__ = ["ANTHILL_VERSION", "AnthillConfig", "Queen", "SQLiteMemory"]
