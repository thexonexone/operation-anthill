"""Scheduler placeholder boundary for v1.7.

v1.6.3 intentionally does not implement the advanced scheduler yet. This file
exists so v1.7 can add TaskScheduler, task leases, queue items, priorities,
retries, and graph validation without changing import paths.
"""

class SchedulerNotImplemented(RuntimeError):
    pass

__all__ = ["SchedulerNotImplemented"]
