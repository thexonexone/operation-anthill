"""Agent communication envelope boundary."""
from ..runtime import AgentMessage

__all__ = ["AgentMessage"]
