"""Shared helper functions for ANTHILL."""
from .runtime import (
    now_utc,
    timestamp_id,
    safe_json_dumps,
    pydantic_deep_copy,
    truncate_text,
    estimate_token_count,
    compact_whitespace,
    create_result_summary,
    build_context_packet_text,
    validate_uuid_id,
    validate_approval_id,
    validate_patch_id,
    validate_source_id,
    should_use_web_search,
    decode_search_url,
    extract_domain,
    normalize_url_for_dedupe,
    source_id_from_url,
    validate_task_dependency_contract,
    extract_verdict,
    infer_task_type,
    extract_json_object,
    validate_safe_patch_path,
)

__all__ = [name for name in globals() if not name.startswith("_")]
