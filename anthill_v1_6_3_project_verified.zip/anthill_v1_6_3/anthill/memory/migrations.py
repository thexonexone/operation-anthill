"""Migration metadata boundary.

The v1.6.3 runtime executes migrations through SQLiteMemory. This module exposes
version constants for future standalone migration runners.
"""
from ..runtime import ANTHILL_SCHEMA_VERSION, ANTHILL_VERSION

__all__ = ["ANTHILL_SCHEMA_VERSION", "ANTHILL_VERSION"]
